﻿/*---------------------------------------------------------------------------
; 	Copyright (C) 2014 Fun Class
; 	All rights reserved.
;
;
; 	FILE NAME  	: INIT.C 
; 	DESCRIPTION	: Using for start the TS programs.
; 	Author		: Jim
; 	REVISION 	bate1.0 
;
;---------------------------------------------------------------------------*/

#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <stdlib.h>
#include <time.h>

#include "init.h"
#include "initialize.c"

void ListAllFiles(char *dirname);
void print(char * filename, int flag);

static int number=1;
static int msgid=0;
pid_t pids[4];

void start_LOG()
{
	char ads[50];
	int id=1;
	if(msgid<1) msg_init(&msgid, 0);
	if( (pids[0]=fork())==0 )
	{
		char log[5];
		sprintf(log, "%d", msgid);
		execl("./LOG","LOG", log, NULL);
		exit(-1);
	}

	get_path("[INIT-LOG]", "/var/log/drs8/LOG", ads, &id);
	if( init_LOG(msgid, id, ads, "[INIT]") )
	{
		printf("init LOG record ERR!\r\n");
		exit(-1);
	}
}

void start_STREAM()
{
	if( (pids[1]=fork())==0 )
	{
		char log[5];
		sprintf(log, "%d", msgid);
		execl("./STREAM","STREAM", log, NULL);
		exit(-1);
	}
}

void start_MAIN()
{
	if( (pids[2]=fork())==0 )
	{
		char log[5];
		sprintf(log, "%d", msgid);
		execl("./MAIN","MAIN", log, NULL);
		exit(-1);
	}
}

void start_UPDATE()
{
	if( (pids[3]=fork())==0 )
	{
		char log[5];
		sprintf(log, "%d", msgid);
		execl("./UPDATE","UPDATE", log, NULL);
		exit(-1);
	}
}

void sig_chld(int signo) 
{
	static long long restart=0;
	static struct timeval tv_bf;
	struct timeval tv;
	pid_t pid; 
	signal(SIGCHLD, sig_chld);
	gettimeofday(&tv, NULL);
	while((pid = waitpid(-1, NULL, WNOHANG | WUNTRACED)) > 0)
	{
		if(pid==pids[0]) {plog(4, "child %d terminated:LOG\r\n", pid);del_msg();sleep(1);start_LOG();plog(0, "LOG restarted! PID=%d\r\n", pids[0]);}
		else if(pid==pids[1]) {plog(4, "child %d terminated:STREAM\r\n", pid);sleep(1);start_STREAM();plog(0, "STREAM restarted! PID=%d\r\n", pids[1]);}
		else if(pid==pids[2]) {plog(4, "child %d terminated:MAIN\r\n", pid);sleep(1);start_MAIN();plog(0, "MAIN restarted! PID=%d\r\n", pids[2]);}
		else if(pid==pids[3]) {plog(4, "child %d terminated:UPDATE\r\n", pid);sleep(1);start_UPDATE();plog(0, "UPDATE restarted! PID=%d\r\n", pids[3]);}
		else plog(4, "child %d terminated:NO NAME!\r\n", pid);
	}
	if(tv.tv_sec - tv_bf.tv_sec <= 300) restart++;
	tv_bf=tv;
	if( restart>=100 )
	{
		struct tm tm;
		localtime_r(&tv.tv_sec, &tm);
		if( (tm.tm_hour-12)>=9 && (tm.tm_hour-12)<=18 )
		{
			plog(4, "INIT program RESTART flag(%d%%) reached 100%%! System reboot!!!\r\n", restart);
			system("reboot");
		}
	}
	puts("INIT program FATAL failure!!!");
	return; 
}

int main()
{
	char file_path[PATH_MAX];
	char address[50];
	int r=0;
	if( geteuid()!=0 ) printf("This program must be run in root!\r\n"),exit(0);
	start_LOG();
	plog(6, "\r\n---------------programs new start----------------------\r\n");
	plog(0, "File system checking...\r\n");
	getcwd(file_path,PATH_MAX);
    plog(6, "Program Path:%s\r\n",file_path);
	plog(6, ".\r\n");
    number=0;
	ListAllFiles(".");
	
	get_path("[TS-ADDRESS]", "/var/tstmp/", address, NULL);

	start_STREAM();
	start_MAIN();
	start_UPDATE();
	signal(SIGCHLD, sig_chld);
	
	if(free_space(address)){
		while(1) sleep(3600);
	}
	
 	while(1)
	{
		sleep(3600);
		if( r=free_space(address) ){
			plog(4, "Disk is FULL(%dMB available)!!!\r\n", r-1);
			time_t tv;
			tv=time(NULL);
			sleep(24*3600-( (tv+8*3600) % (24*3600) ) +60);
			system("reboot");
		}
	}
	return 0;
}

int isFile(const char* FileName)			//判断文件是否属于文本文件
{
	char name[8]={0};
	int l = strlen(FileName);
	if( l<4 )return 0;			//直接过滤文件名短的非文本文件
	else
	{
		snprintf( name, 5, "%s", FileName );
		if( !strcmp( name, "tmp_") )	//通过比较后缀名的方式判断是否为文本文件
			return 1;
		else return 0;
	}
}

void ListAllFiles(char *dirname)			//遍历所有文件函数
{
	int r;
	char path[PATH_MAX];				//存放文件路径
	struct dirent *filename;
	DIR *dir;
 
	dir = opendir(dirname);				//打开文件夹函数
	if(dir == NULL)
	{
		plog(4, "Error:%s:%m!\r\n", dirname);	//打开错误，则输出错误信息
		return;
	}
 
	while((filename = readdir(dir)) != NULL)	//循环遍历文件夹里内容
	{
  //跳过目录结构下面的两个.和..的目录
		if(!strcmp(filename->d_name,".") || !strcmp(filename->d_name,".."))
			continue;

  		//非常好用的一个函数，比什么字符串拼接什么的来的快的多
  		sprintf(path,"%s/%s",dirname,filename->d_name);

  		struct stat s;
		lstat(path,&s);
  
		if(S_ISDIR(s.st_mode))
		{
			print(filename->d_name,1);
			number++;
			ListAllFiles(path);		//递归调用
			number--;
		}
		else
			if( isFile(filename->d_name) )
			{
				r=unlink(filename->d_name);
				if(r) plog(4, "unlink %s error:%s", filename->d_name, strerror(errno) );
				print(filename->d_name,2);
			}
			else
				print(filename->d_name,0);
	}
	closedir(dir);					//关闭目录
}

void print(char * filename, int flag)
{
	int i;
	for(i=0;i<number;i++)
	{
		plog(6, "|    ");
	}
	switch( flag )
	{
		case 0: plog(6, "|--%s\r\n", filename); break;
		case 1: plog(6, "+%s/\r\n",filename); break;
		case 2: plog(6, "|--%s (Residual file DELETED!!!)\r\n", filename); break;
	}
}

