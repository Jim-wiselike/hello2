#include <stdio.h>
#include <stdlib.h>
#include "LIVE.h"

typedef struct List{
	cmd_pakg* head;
	cmd_pakg* end;
}List;

void add_list(List* l, cmd_pakg cmd)
{
	cmd_pakg* new=(cmd_pakg*)malloc(sizeof(cmd_pakg));
	*new = cmd;
	if(l->head==NULL)
	{
		l->head = new;
		l->end = new;
		return;
	}
	l->end->next = new;
	l->end = new;
	return;
}

void Free(List* l)
{
	cmd_pakg* head=l->head;
	while(l->head!=l->end)
	{
		l->head = head->next;
		free(head);
		head = l->head;
	}
	if(l->head!=NULL) free(l->head);
	l->head=NULL;
	l->end =NULL;
}

void del_list(List* l, cmd_pakg cmd)
{
	cmd_pakg* before=l->head;
	cmd_pakg* after;
	if(l->head==NULL)
	{
		return;
	}
	if(before->cmd_chan==cmd.cmd_chan && before->ip_addr==cmd.ip_addr)
	{
		if(l->end==before){ free(before); l->end=NULL; l->head=NULL; return; }
		l->head = before->next;
		free(before);
		return;
	}
	if(before==l->end)return;
	after = before->next;
	while(after!=l->end)
	{
		if(after->cmd_chan==cmd.cmd_chan && after->ip_addr==cmd.ip_addr)
		{
			before->next = after->next;
			free(after);
			return;
		}
		else
		{
			before = after;
			after = after->next;
		}
	}
	if(after->cmd_chan==cmd.cmd_chan && after->ip_addr==cmd.ip_addr)
	{
		l->end = before;
		free(after);
		return;
	}
	return;
}

cmd_pakg find_list_pid(List* l, int pid)
{
	cmd_pakg* head=l->head;
	cmd_pakg ans={0};
	while(head!=l->end)
	{
		if(head->pid==pid)
		{
			ans = *head;
			return ans;
		}
		head=head->next;
	}
	if(head==NULL) return ans;
	if(head->pid==pid)
	{
		ans = *head;
		return ans;
	}
	return ans;
}

void print(List* l)
{
	cmd_pakg* head=l->head;
	if(l->end==NULL){puts("dsafsadfsadf");return;}
	while(head!=l->end)
	{
		printf("%d\r\n", head->cmd_chan);
		head = head->next;
	}
	printf("%d\r\n\r\n", l->end->cmd_chan);
}

/*
void main()
{
	List list={0};
	cmd_pakg cmd={110,123455,110};add_list(&list,cmd);
	cmd_pakg cmd1={111,123455,111};add_list(&list,cmd1);
	cmd_pakg cmd2={112,123455,112};add_list(&list,cmd2);
	cmd_pakg cmd3={113,123455,113};add_list(&list,cmd3);
	cmd_pakg cmd4={114,123455,114};add_list(&list,cmd4);
	cmd_pakg cmd5={115,123455,115};add_list(&list,cmd5);
	cmd_pakg cmd6={116,123455,116};add_list(&list,cmd6);
	print(&list);
	del_list(&list, find_list_pid(&list,111));	print(&list);
	del_list(&list, find_list_pid(&list,115));	print(&list);
	del_list(&list, find_list_pid(&list,116));	print(&list);
	del_list(&list, find_list_pid(&list,110));	print(&list);
	del_list(&list, find_list_pid(&list,113));	print(&list);
	del_list(&list, find_list_pid(&list,112));	print(&list);
	del_list(&list, find_list_pid(&list,115));	print(&list);
	del_list(&list, find_list_pid(&list,114));	print(&list);
	del_list(&list, find_list_pid(&list,110));	print(&list);
	Free(&list);
}
*/














