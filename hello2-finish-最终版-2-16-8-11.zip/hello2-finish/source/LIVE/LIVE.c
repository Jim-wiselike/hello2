#include <fcntl.h>
#include <sys/socket.h>
#include <sys/mman.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "initialize.h"
#include "LIVE.h"
#include "queue.c"

__asm__(".symver memcpy,memcpy@GLIBC_2.2.5");
List list={0};
stream_data* data;
unsigned char *monitor=NULL;
unsigned long timer;
static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
int suspend=1;


extern int msgid;
fun_names plugin()
{
	fun_names a=get_argv(1, "LIVE_MAIN");
	return a;
}

void re_start(int pid)
{
	cmd_pakg cmd=find_list_pid(&list, pid);
	del_list(&list, cmd);
	if( (cmd.pid=fork())==0 )
	{
		Free(&list);
		LIVE_CLIENT(cmd);
		exit(-1);
	}
	else add_list(&list, cmd);
}

void sig_chld_live(int signo) 
{ 
	pid_t pid; 
	signal(SIGCHLD, sig_chld_live);
	while((pid = waitpid(-1, NULL, WNOHANG | WUNTRACED)) > 0)
	{
		cmd_pakg tep=find_list_pid(&list, pid);
		if(tep.cmd_chan==0){ plog(4, "NO NAME Class terminated.(PID=%d)!\r\n", pid); continue; }
		if(monitor[tep.cmd_chan] != 0)
		{
				plog(4, "Prepare for Class %d(PID=%d) LIVEING Broadcast RESTART.\r\n", tep.cmd_chan, pid);
				re_start(pid);
				continue;
		}
		else
		{
			plog(3, "The Class %d(PID=%d) LIVEING Broadcast CLOSED. monitor:%d(Raw data)\r\n", tep.cmd_chan, pid, monitor[tep.cmd_chan]);
			continue;
		}
	}
// 	puts("LIVE program FATAL failure!!!");
	return; 
}

int stream_pipe_init(void)
{
	int pipe;
	mkfifo("tmp_socket_0.pipe",0666);
	pipe=open("tmp_socket_0.pipe",O_RDWR);
	shutdown(pipe,SHUT_RD);
	return pipe;
}

void state_init(void)
{
	int fd;
	fd=open("tmp_dat_live",O_RDWR|O_CREAT|O_EXCL,0666);
	if(fd==-1)
	{
		fd=open("tmp_dat_live",O_RDWR);
	}
	ftruncate(fd, 256);
	monitor = mmap(0, 256, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
	monitor[0]='B';
	close(fd);
}

int cmd_parse(unsigned char cmd, unsigned char num)
{
	if(monitor[num]==0  && cmd==1)
	{
		plog(0, "Prepare for class %d's LIVEING Broadcast.\r\n", num);
		monitor[num]=0xFE;
		return 1;
	}
	
	if((monitor[num]<STUDENTS_NUM+1 || monitor[num]==0xFF) && cmd==1) return 0;
	if(monitor[num]>STUDENTS_NUM  && cmd==1)
	{
		plog(5, "Rec retry for class %d, IGNORE the error code %d!\r\n", num, monitor[num]);
		monitor[num] = 0xFE;
		return 0;
	}
	if(monitor[num]==0   && cmd==0) return 0;
	if((monitor[num]>STUDENTS_NUM && monitor[num]<0xFF)  && cmd==0)
	{
		plog(5, "Erase the error code %d for class %d!\r\n", monitor[num], num);
		monitor[num] = 0;
		return 0;
	}
	if((monitor[num]<STUDENTS_NUM+1 || monitor[num]==0xFF) && cmd==0)
	{
		monitor[num] = 0;
		plog(0, "Prepare to finish Class %d's LIVEING Broadcast.\r\n", num);
		return 0;
	}
	plog(4, "Function cmd_parse execute ERR! cmd=%d,num=%d,monitor[%d]=%d(Raw data)\r\n", cmd, num, num, monitor[num]);
	return 0;
}

void start_client(unsigned char * cmd_buf)
{
	cmd_pakg cmd;
	cmd.cmd_chan=cmd_buf[1];
	cmd.ip_addr = cmd_buf[2]	 | cmd_buf[3]<<8  |
				  cmd_buf[4]<<16 | cmd_buf[5]<<24;
	cmd.next = NULL;	
	if( cmd_buf[1]==0 )
	{
		plog(4, "LIVE command ERR, there is no class 0!!!\r\n");
		return;
	}

	if(cmd.ip_addr==0 || cmd.ip_addr==-1)
	{
		plog(4, "LIVE command ERR, command's IP is 0.0.0.0 or 255.255.255.255\r\n");
		return;
	}
	if( cmd_parse(cmd_buf[0], cmd_buf[1]) )
	{
		if( (cmd.pid=fork())==0 )
		{
			Free(&list);
			LIVE_CLIENT(cmd);
			exit(-1);
		}
		else
		{
			add_list(&list, cmd);
		}
	}
	else if(cmd_buf[0]==1)
			plog(4, "JT-WEBS send duplicate command.\tmonitor[%d]=%d(Raw data) cmd:START\r\n", cmd_buf[1], monitor[cmd_buf[1]]);	
}

void* main_thread(void* cp)
{
	unsigned char cmd_buf[1423];
	unsigned char *pcmd_buf;
	int pakg_num;
	int i, r;
	struct timeval timeout;
	int offset = 0;
	
	int client_fd=*(int*)cp;
	free(cp);
	pthread_detach(pthread_self());
	timeout.tv_sec = 10; 
	timeout.tv_usec = 0;
	setsockopt(client_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(struct timeval));
	setsockopt(client_fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(struct timeval));
	while(1)
	{
	//recv command packege
		bzero(cmd_buf, sizeof(cmd_buf));
		
		r = recv(client_fd, cmd_buf ,sizeof(cmd_buf)-6, 0);
		if ( r==-1 || r==0 || cmd_buf[0]!=WEB_TO_DRS_HEAD )
		{
			if( r==-1 || r==0 )
			{
				if(errno==EINTR) continue;
				plog(4, "JT-WEBS(fd:%d) break the socket automatically. Break code:%d, strerror=%s\r\n", client_fd, r, strerror(errno));
				break;
			}
			else 
			{
				plog(4, "JT-WEBS(fd:%d) send error cmd:\tHEAD=%c(%d)\tr=%d\t\r\n", client_fd, cmd_buf[0], cmd_buf[0], r);
				continue;
			}
		}
		else
		{
			pcmd_buf=cmd_buf;
			offset = 0;
			while(1)
			{
				pakg_num = pcmd_buf[1];
				if(pakg_num!=0)
				{
					plog(0, "Command parse:head [%c]\tcounts %d\r\n", pcmd_buf[0] ,pakg_num );
				}
				if(offset+pakg_num*6+2>r)break;
				for(i=0; i<pakg_num; i++)
				{
					plog(0, "Command %d:Class %u %s the LIVEING Broadcast. The coder's IP=%u.%u.%u.%u\r\n", i+1,
						   pcmd_buf[3+6*i], pcmd_buf[2+6*i]==1?"START":"CLOSE", pcmd_buf[4+6*i], pcmd_buf[5+6*i], pcmd_buf[6+6*i], pcmd_buf[7+6*i]);
					start_client(pcmd_buf+2+6*i);
				}
				if((offset+pakg_num*6+2<r+1) && (pcmd_buf[pakg_num*6+2]=='Z'))
				{
					pcmd_buf=pcmd_buf+pakg_num*6+2;
					offset+=pakg_num*6+2;
				}
				else
					break;
			}
		}
		//send back message
		send(client_fd, monitor, 256, 0);
		if(r<1)plog(4, "Socket send feedback  failed! Err code %d. %s\r\n", r, strerror(errno));
	}
//finish
	close ( client_fd );
}

void livemain()
{
	int server_fd, *client_fd;
	int r;

	struct sockaddr_in server_addr = {0};
	struct sockaddr_in client_addr = {0};
	socklen_t len;
	int opt = SO_REUSEADDR;
	pthread_t live_main;

//start socket
	server_fd=socket( AF_INET,SOCK_STREAM ,6 );
	if ( server_fd==-1 )
	{
		close ( server_fd );
		plog(4, "socket err:%s\r\n", strerror(errno));
		return;
	}
	
	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
//bind&listen
	server_addr.sin_family = AF_INET;
	server_addr.sin_port   = htons( SERVER_PROT );
	server_addr.sin_addr.s_addr=htonl(INADDR_ANY); 
	r = bind(server_fd, (struct sockaddr*) &server_addr, sizeof(server_addr));
	if( r==-1 )
	{
		close ( server_fd );
		plog(4, "bind err:%s\r\n", strerror(errno));
		return;
	}

	r = listen( server_fd , 2 );
	if( r==-1 )
	{
		close ( server_fd);
		plog(4, "listen err:%s\r\n",  strerror(errno));
		return;
	}
	else
	{
		plog(0, "livemain Port:%d\tListenning!\r\n", SERVER_PROT);
	}
	
//accept client
while(1)
{
	len = sizeof( client_addr );
	client_fd = (int *)malloc( sizeof(int) );
	*client_fd = accept( server_fd, (struct sockaddr*) &client_addr, &len );
	if( *client_fd==-1 )
	{
		free(client_fd);
		plog(4, "livemain:accept err:%m\r\n" );
		continue;//break;
	}
	else
	{
		plog(3, "JT-WEBS connected:%d,ip:%s:%u\r\n" ,
				*client_fd,								//num
				inet_ntoa( client_addr.sin_addr ),		//show ip
				ntohs(client_addr.sin_port) );			//show port number
		
		r = pthread_create(&live_main, NULL, &main_thread, client_fd);
		if (r != 0)
		{
			plog(4, "JT-WEBS pthread create error, pthread can't create:%s\r\n", strerror(errno));
			close ( *client_fd );
			free(client_fd);
			sleep(3);
		}
	}
}
	close ( server_fd );
	plog(4, "livemain core break !\r\n" );
	return;
}

int mem_cpy_ser(unsigned char *des, unsigned char *sor, int* loc, int add)
{
	int lenth=*loc+add;
	if( lenth > SOURCE_BUFF_SIZE)
	{
		memcpy(des+*loc, sor, SOURCE_BUFF_SIZE-*loc);
		memcpy(des, sor+SOURCE_BUFF_SIZE-*loc, lenth-SOURCE_BUFF_SIZE);
		*loc = lenth-SOURCE_BUFF_SIZE;
		return 1;
	}
	else
	{
		memcpy(des+*loc, sor, add);
		if(lenth ==SOURCE_BUFF_SIZE){ *loc=0;return 1;}
		else { *loc=lenth; return 0; }
	}
}
void* client_recv(void *cp)
{
	cmd_pakg *pakg=(cmd_pakg *)cp;
	int serve_fd;
	int r;
	struct timeval timeout;
	char name[255];
	unsigned char ser_buf[32768];
	struct timeval time_tmp;
	unsigned long time_a, time_b=0;
	int pipe=stream_pipe_init();
	
	stream_cmd_pakg pkg;
	pkg.chan =pakg->cmd_chan;
	pkg.cmd=1;
	pkg.ip_addr=pakg->ip_addr;
	pkg.port=5223;
	free(pakg);

	pthread_detach(pthread_self());
	plog(0, "Class %d. Stream service start successfully.\r\n", pkg.chan);
	int restart = 0;
	errno=0;
//Start socket
while(1)
{
loop:
	if( monitor[pkg.chan]==0 )exit(0);
// 	else if( monitor[pkg.chan]==0xFF )
// 	{
// 		usleep(500000);
// 		continue;
// 	}
	if(pipe!=-1) r=write(pipe,&pkg,sizeof(stream_cmd_pakg));
	else r=1;
	if(r==1)plog(5, "Class %d. Activate STREAM again.\r\n", pkg.chan);
	else plog(0, "Class %d. Activate STREAM by sending stream pipe %d bytes:%s\r\n", pkg.chan, r, strerror(errno));
	usleep(100000);
    struct sockaddr_un addr={0};

    serve_fd = socket(AF_UNIX, SOCK_STREAM, 0);
 
    addr.sun_family = AF_UNIX;
	sprintf(name, "./tmp_socket_%d.%d.%d.%d", pkg.ip_addr%256,(pkg.ip_addr>>8)%256, (pkg.ip_addr>>16)%256, pkg.ip_addr>>24);

    snprintf(addr.sun_path, UNIX_PATH_MAX, "%s", name);
    r=connect(serve_fd,(struct sockaddr *) &addr,sizeof(struct sockaddr_un));
	if ( r==-1 )
	{
		close(serve_fd);
		plog(4, "Class %d. Connect err:%s\r\n", pkg.chan, strerror(errno));
		usleep(210000);
		monitor[pkg.chan]=CODER_ERROE;
		goto loop;
	}
	else
	{
		close(pipe);
		pipe = -1;
//		if(monitor[pkg.chan]>STUDENTS_NUM) monitor[pkg.chan]=1;
	}
	plog(0, "Class %d LIVEING Broadcast START!\r\n", pkg.chan);
	
//Receive packeges
	r=0;
	timeout.tv_sec = 1; 
	timeout.tv_usec = 0;
	setsockopt(serve_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(struct timeval));
	while(1)
	{
// 		if(monitor[pkg.chan]>0 && monitor[pkg.chan]<0xFF) suspend=1;
// 		else if( suspend ){ plog(5, "Class %d have no students. LIVEING Broadcast SUSPEND!\r\n", pkg.chan); break; }
		if( monitor[pkg.chan]==0 ) break;
		r = recv(serve_fd, ser_buf, sizeof(ser_buf), 0);
		if(r<1)
		{
			suspend=1;
			plog(4, "Class %d. Socket break form STREAM! MSG:%s. AUTO Repaired.(CLOSE:%d)\r\n", pkg.chan, strerror(errno), 5-restart);
			if(restart++ > 4){ monitor[pkg.chan]=NETWORK_ERR; restart--; break; }
		}
		else
		{
			gettimeofday(&time_tmp,NULL);
			time_a = 1000000*time_tmp.tv_sec+time_tmp.tv_usec;
			timer = time_a-time_b;
			time_b = time_a;
			if( mem_cpy_ser(data->source, ser_buf, &data->fp, r) ) restart=0;
			if(suspend)
			{
				suspend=0;
				if(monitor[pkg.chan]>STUDENTS_NUM) monitor[pkg.chan]=0xff;
			}
		}
	}
	if( suspend && monitor[pkg.chan]>STUDENTS_NUM )
	{
		sleep(5);
	}
	close(serve_fd);
}
}

int StartListen(int cmd_chan)
{
	struct sockaddr_in addr = {0};
	int r=0;
	int opt = SO_REUSEADDR;
	int server = socket(AF_INET , SOCK_STREAM , 6);
	if (server == -1)
	{
		close ( server );
		plog(4, "Class%d socket err:%m\r\n", cmd_chan, strerror(errno));
		monitor[cmd_chan] = SOCKET_ERR;
		sleep(1);
		return -1;
	}
	setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

	addr.sin_family = AF_INET;
	addr.sin_port   = htons( cmd_chan+5499 );
	addr.sin_addr.s_addr=htonl(INADDR_ANY); 
	r = bind(server, (struct sockaddr*) &addr, sizeof(addr));
	if( r==-1 )
	{
		close ( server );
		plog(4, "Class%d bind err:%s\r\n", cmd_chan, strerror(errno));
		monitor[cmd_chan] = BIND_ERR;
		sleep(1);
		return -1;
	}

	r = listen( server , 10 );
	if( r==-1 )
	{
		close ( server );
		plog(4, "Class%d listen err:%s\r\n", cmd_chan, strerror(errno));
		monitor[cmd_chan] = LISTEN_ERR;
		sleep(1);
		return -1;
	}
	else
	{
		plog(3, "Class%d. CLIENT Port:%d\tListenning!\r\n", cmd_chan, cmd_chan+5499);
	}
	return server;
}

int mem_cpy_cli(unsigned char *des, unsigned char *sor, int* loc, int ser)
{
	int lenth;
	if(*loc < ser)
	{
		lenth = ser-*loc;
		if(lenth>CLIENT_BUFF_SIZE)
		{
			memcpy(des, sor+*loc, CLIENT_BUFF_SIZE);
			*loc += CLIENT_BUFF_SIZE;
			return CLIENT_BUFF_SIZE;
		}
		else
		{
			memcpy(des, sor+*loc, lenth);
			*loc += lenth;
			return lenth;
		}
	}
	else
	{
		lenth = SOURCE_BUFF_SIZE-*loc;
		if(lenth>CLIENT_BUFF_SIZE)
		{
			memcpy(des, sor+*loc, CLIENT_BUFF_SIZE);
			*loc += CLIENT_BUFF_SIZE;
			return CLIENT_BUFF_SIZE;
		}
		else
		{
			memcpy(des, sor+*loc, lenth);
			if(ser>CLIENT_BUFF_SIZE-lenth)
			{
				memcpy(des+lenth, sor, CLIENT_BUFF_SIZE-lenth);
				*loc = CLIENT_BUFF_SIZE-lenth;
				return CLIENT_BUFF_SIZE;
			}
			else
			{
				memcpy(des+lenth, sor, ser);
				*loc = ser;
				return ser+lenth;
			}
		}
	}
}

void* client_send(void* cp)
{
	int fd=((thread_cp*)cp)->fd;
	int chan=((thread_cp*)cp)->chan;
	unsigned char des[CLIENT_BUFF_SIZE];
	int fp=data->fp;
	int r=1;
	struct timeval timeout;
	unsigned long timer_b=10000;
	timeout.tv_sec = 3; 
	timeout.tv_usec = 0;
	free(cp);
	pthread_detach(pthread_self());
	setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(struct timeval));
	if(monitor[chan]<STUDENTS_NUM+1) monitor[chan]++;
	else monitor[chan]=1;
	plog(0, "Client(fd:%d) connected in, Total:%d!\r\n", fd, monitor[chan]);
	while(1)
	{
		if(monitor[chan]>STUDENTS_NUM)
		{
			plog(4, "CLIENT error. Class%d:%d(Raw data)\r\n", chan, monitor[chan]);
			break;
		}
		if(fp!=data->fp)
		{
			r = mem_cpy_cli(des, data->source, &fp, data->fp);
			r = send(fd, des, r, 0);
			if(r<1)
			{
				break;
			}
		}
		else
		{
			if(timer>10 && timer<1000000)
			{
				timer_b=(timer_b+timer)/2;
				usleep(timer_b);
			}
			else usleep(timer_b);
		}
	}
	pthread_mutex_lock(&mutex);
	plog(0, "Client breaked(fd:%d). Total:%d. MSG:%s\r\n", fd, monitor[chan], strerror(errno));
	if(monitor[chan]>1 && monitor[chan]<STUDENTS_NUM+1)monitor[chan]--;
	else if(monitor[chan]==1)monitor[chan]=0xFF;
	pthread_mutex_unlock(&mutex);
	close(fd);
}

void LIVE_MAIN()
{
	char ads[50];
	int id=7;
	prctl(PR_SET_NAME, "LIVE-MAIN", NULL, NULL, NULL);
	get_path("[LIVE-LOG]", "/var/log/drs8/LIVE", ads, &id);
	if( init_LOG(msgid, id, ads, "[LIVE]") )
		plog(4, "init LOG error. This is [LIVE_MAIN]!!!\r\n");
	plog(6, "\r\n------------------------LIVE new start------------------------\r\n" );
	signal(SIGCHLD, sig_chld_live);
	state_init();
	
	signal(SIGPIPE, SIG_IGN);
//去掉fd继承
	livemain();
}


void LIVE_CLIENT(cmd_pakg cmd)
{
	char name[15];
	int res;
	pthread_t live;
	int server=-1;
	struct sockaddr_in client_addr = {0};
	socklen_t len;
	sprintf(name, "LIVE-CLASS%d", cmd.cmd_chan);
	prctl(PR_SET_NAME, name, NULL, NULL, NULL);
	
	data = (stream_data*)malloc(sizeof(stream_data));
	memset(data, 0, sizeof(stream_data));
	cmd_pakg* cp=(cmd_pakg*)malloc(sizeof(cmd_pakg));
	*cp = cmd;
	res = pthread_create(&live, NULL, &client_recv, cp);
	usleep(1);
	if (res != 0)
	{
		plog(4, "Class %d's LIVEING Broadcast error, pthread can't create:%s\r\n", cmd.cmd_chan, strerror(errno));
		monitor[cmd.cmd_chan] = CORE_BREAK;
		free(cp);
		exit(-1);
	}
	
	while( (server=StartListen(cmd.cmd_chan)) ==-1)plog(4, "StartListen ERR\r\n");
	len = sizeof( client_addr );
	while(1)
	{
		if( monitor[cmd.cmd_chan]==STUDENTS_NUM )
		{
			if(server!=-1)
			{
				close(server);
				server=-1;
			}
			sleep(3);
			continue;
		}
		else if(server==-1) while( (server=StartListen(cmd.cmd_chan)) ==-1)plog(4, "StartListen ERR\r\n");
		thread_cp *cp2=(thread_cp*)malloc(sizeof(thread_cp));
		cp2->chan = cmd.cmd_chan;
		cp2->fd = accept( server, (struct sockaddr*) &client_addr, &len );
		if(cp2->fd==-1)
		{
			plog(4, "Class %d's service can't ACCPET:%s\r\n", cmd.cmd_chan, strerror(errno));
			sleep(1);
			free(cp2);
			continue;
		}
		if(suspend)
		{
			sleep(1);
			close(cp2->fd);
			free(cp2);
			continue;
		}
		res = pthread_create(&live, NULL, &client_send, (void*)cp2);
		usleep(1);
		if (res != 0)
		{
			plog(4, "Class %d's client can't create:%s\r\n", cmd.cmd_chan, strerror(errno));
			free(cp2);
		}
	}
}




