#ifndef _LIVE_H
#define _LIVE_H 1

#define SERVER_PROT			9972
#define WEB_TO_DRS_HEAD		'Z'
#define DRS_TO_WEB_HEAD		'B'

#define SOURCE_BUFF_SIZE	1880000
#define CLIENT_BUFF_SIZE	18800
#define SIGNAL_PAKG_SIZE 	6
#define MAXNUM 				100
#define UNIX_PATH_MAX 		108
#define STUDENTS_NUM		199

typedef struct cmd_pakg{
	unsigned char cmd_chan;
	unsigned int ip_addr;
	int pid;
	struct cmd_pakg* next;
}cmd_pakg;

typedef struct stream_cmd_pakg{
	unsigned char chan;						//命令号
	unsigned char cmd;						//时间
	unsigned int ip_addr;						//ip地址
	unsigned int port;
}stream_cmd_pakg;

typedef struct stream_data{
	unsigned char source[SOURCE_BUFF_SIZE];
	int fp;
}stream_data;

typedef struct thread_cp{
	int fd;
	int chan;
}thread_cp;

//error define
#define CODER_ERROE			200
#define SOCKET_ERR			201
#define BIND_ERR			202
#define LISTEN_ERR			203
#define CONNECT_ERR			204
#define ACCEPT_ERR			205
#define FILE_CREAT_ERR		206
#define RECEV_ERR			207
#define NETWORK_ERR			208
#define WRITE_ERR			209
#define NETWORK_BREAK		210
#define CORE_BREAK			211
#define TIME_UP				212

void LIVE_CLIENT(cmd_pakg cmd);

#endif
