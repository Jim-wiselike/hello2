﻿/*---------------------------------------------------------------------------
; 	Copyright (C) 2014 Fun Class
; 	All rights reserved.
;
;
; 	FILE NAME  	: LOG.C 
; 	DESCRIPTION	: Log record 
; 	Author		: Jim
; 	REVISION 1.0 
;
;---------------------------------------------------------------------------*/

#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <stdarg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "init.h"
#include "log.h"
#include "initialize.h"

log_qu* log_head=NULL;
char logpath[50];
path_save all_paths={0};

int plogL(const char *pathname, int type, const char *buf) 
{
	int file_fd;
	char path[FILE_PATH_L];
	char sprint_buf[MSG_L+20];
	struct timeval tv;
	struct tm tm;
	gettimeofday(&tv, NULL);
	localtime_r(&tv.tv_sec, &tm);
	sprintf(path, "%s%d-%d-%d.log",pathname, tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday);
	file_fd = open(path, O_RDWR|O_CREAT|O_EXCL, 00666 );
	if( file_fd==-1 )
	{
		file_fd = open(path, O_RDWR|O_CREAT|O_APPEND, 00666 );
		if( file_fd==-1 )return 1;
	}
	if( type==6 ) sprintf(sprint_buf, "%s", buf);
	else
	{
		sprintf(sprint_buf, "[%02d:%02d:%02d:%06dus] ", \
		tm.tm_hour, tm.tm_min, tm.tm_sec, (int)(tv.tv_usec));
		switch(type)
		{
			case 5:sprintf(sprint_buf+20,"%s %s", "WARN ", buf);break;
			case 4:sprintf(sprint_buf+20,"%s %s", "ERROR", buf);break;
			case 3:sprintf(sprint_buf+20,"%s %s", "MSG  ", buf);break;
			default:sprintf(sprint_buf+20,"%s %s", "     ", buf);break;
		}
	}
	write(file_fd , sprint_buf , strlen(sprint_buf));
	close( file_fd );
	return 0;
}

void plog_self(int type, const char *fmt, ...) 
{
	va_list args;
	char sprint_buf[MSG_L]={0};

	if(type==3) sprintf(sprint_buf, "------------------\r\n");
	va_start(args, fmt);
	vsprintf(sprint_buf, fmt, args);
	va_end(args);
	plogL(logpath, type, sprint_buf);
}

void msg_recv_s(int msgid, msg_buf_s* mbuf)			//消息队列接收函数
{
	bzero(mbuf,sizeof(msg_buf));
	msgrcv(msgid, mbuf, sizeof(mbuf->data), 666, 0);
}

void msg_recv(int msgid, msg_buf* mbuf)			//消息队列接收函数
{
	bzero(mbuf,sizeof(msg_buf));
	msgrcv(msgid, mbuf, sizeof(mbuf->data), 777, 0);
}

void msg_send_s(int msgid, msg_buf_s* mbuf)			//消息队列发送函数
{
	mbuf->type=mbuf->data.id;
//printf("idd=%d\r\n", mbuf->data.id);
	msgsnd(msgid, mbuf, sizeof(mbuf->data), 0);
}
//int aaaaa;
void* pthread(void* cp)	
{
//	printf("num=%d\r\n",aaaaa++);
	int id=((msg_add*)cp)->id;
	char path[FILE_PATH_L+1]={0};
	strncpy(path, ((msg_add*)cp)->path, FILE_PATH_L);
	int msgid, r;
	pthread_detach(pthread_self());

	while( msg_init(&msgid, id)>0 )
	{
		plog_self(4, "[LOG]path:%d\tid=%s\r\n", id, path);
		sleep(20);
	}
	plog_self(0, "[LOG]msgpath=%s\t id(%d) msgid = %d\r\n",path, id, msgid);
//	printf( "[LOG]msgpath=%s\t id(%d) msgid = %d\r\n",path, id, msgid);
	msg_buf mbuf;
	free(cp);
	CreateDirectoryEx(path);
	while(1)
	{
		msg_recv(msgid, &mbuf);
		r = plogL(path, mbuf.data.type, mbuf.data.msg);
		if( r ) 
		{
			CreateDirectoryEx(path);
			plog_self(4, "[LOG]Create new directory!\r\n");
		}
	}
}

int find(log_qu* head, msg_add *cp)
{
	if(head==NULL) return 0;
	while(head!=NULL)
	{
		if(head->id==cp->id && !strcmp(head->path,cp->path)) return 1;
		head = head->next;
	}
	return 0;
}

log_qu* create(log_qu* head, msg_add* cp)
{
	log_qu* q = head;
	if(head==NULL)
	{
		q = (log_qu*)malloc(sizeof(log_qu));
		q->id = cp->id;
		sprintf(q->path, "%s", cp->path);
		q->next = NULL;
		return q;
	}
	while( q->next!=NULL )
	{
		q = q->next;
	}
	q->next = (log_qu*)malloc(sizeof(log_qu));
	q->next->next = NULL;
	q->id = cp->id;
	sprintf(q->path, "%s", cp->path);
	return head;
}

int cmd_parse(msg_add *cp)
{
	if(find(log_head, cp))
		return 0;
	log_head = create(log_head, cp);
	return 1;
}

void* pthread_clean( )	
{
	path_save* head;
	char cmd_tmp[255];
	pthread_detach(pthread_self());
	while(1){
		head = &all_paths;
		while(head->next!=NULL){
			sprintf(cmd_tmp, "find %s/ -mtime +60 -type f -name *.log -exec rm -f {} \\;", head->path);
			system(cmd_tmp);
			head = head->next;
		}
		sleep(25*3600);
	}
}

static void add_path(const char* path)
{
	path_save* head = &all_paths;
	while(head->next!=NULL)
	{
		head = head->next;
	}
	head->path = (char* )malloc(strlen(path)+1);
	snprintf(head->path, strlen(path)+1, "%s", path);
	
	head->next = (path_save*)malloc(sizeof(path_save));
	head->next->path=NULL;
	head->next->next=NULL;
}


void main(int argc, char** argv)
{
	int msgid=atoi(argv[1]);
	msg_buf_s mbuf;
	msg_add* p_arg;
	pthread_t thread[100];
	int i=0;
	int r;
	get_path("[INIT-LOG]", "/var/log/drs8/LOG/", logpath, NULL);

	CreateDirectoryEx(logpath);
	add_path(logpath);
	pthread_create(thread+99, NULL, &pthread_clean, NULL);
//	system(cmd_tmp);
	plog_self(0, "[LOG]LOG path=%s\tmsgid = %d\r\n", logpath, msgid);

//puts("LOG start!");
	while(1)
	{
		bzero(&mbuf, sizeof(msg_buf_s));
		msg_recv_s(msgid, &mbuf);
		if(mbuf.data.cmd==START)
		{
//			printf("LOG_path=%s\r\n", mbuf.data.path);
			if(i>29 || mbuf.data.path[0]!='/')
			{
				mbuf.data.cmd=FAILL;
				msg_send_s(msgid, &mbuf);
				continue;
			}
			p_arg = (msg_add*)malloc(sizeof(msg_add));
			p_arg->id = mbuf.data.id;
			strncpy(p_arg->path, mbuf.data.path, FILE_PATH_L);
			if( cmd_parse(p_arg) )
			{
				CreateDirectoryEx(p_arg->path);
				add_path(p_arg->path);
				r = pthread_create(thread+i, NULL, &pthread, (void*)p_arg);
				if( r!=0 )								//异常处理
				{
					plog_self(4, "[LOG]thread[%d] create for id(%d) err! %m\r\n", i, mbuf.data.id);
					mbuf.data.cmd=RETRY;
					msg_send_s(msgid, &mbuf);
					free(p_arg);
				}
				else
				{
					plog_self(0, "[LOG]thread[%d] create for id(%d) sucessfull!\r\n", i, mbuf.data.id);
					mbuf.data.cmd=SUCCESS;
					msg_send_s(msgid, &mbuf);
					i++;
				}
			}
			else
			{
				plog_self(0, "[LOG]msgpath=%s\tid:%d\r\n",p_arg->path, p_arg->id);
				plog_self(5, "[LOG]Log pthread exist!\r\n");
				free(p_arg);
				mbuf.data.cmd=SUCCESS;
				msg_send_s(msgid, &mbuf);
			}
		}
	}
}




