
#ifndef AVFORMAT_MP4SEGMENT_H
#define AVFORMAT_MP4SEGMENT_H

#ifdef	__cplusplus
#include "stdafx.h"
#endif

typedef struct ClipFrame
{
	int64_t mindts;
	int64_t maxdts;
} ClipFrame;

typedef struct ClipFrames
{
	int clipFrameCount;
	ClipFrame clipframe[100];  
} ClipFrames;

int mp4_Segment(char *src_filename, char *dest_filename, ClipFrames clipframes, int *mp4_Segment_pec);

#endif /* AVFORMAT_MP4SEGMENT_H */
