#ifndef _SEG_H_
#define _SEG_H_

#define SERVER_PROT			9968
#define WEB_TO_DRS_HEAD		'S'

#define PAKG_SIZE			1024
#define DRS_TO_WEB_HEAD		'F'
#define BUFF_SIZE			1600

struct msgbuf
{
	long type;
	unsigned char data[BUFF_SIZE];
};

typedef struct queue{
	char file[25];
	char file_from[25];
	unsigned char cmd[1600];
	int stat;
	struct queue* next;
}queue;

typedef struct List{
	struct queue* head;
	struct queue* end;
	int num;
}List;

//error define
#define SOCKET_ERR			201
#define BIND_ERR			202
#define LISTEN_ERR			203
#define CONNECT_ERR			204
#define ACCEPT_ERR			205
#define FILE_CREAT_ERR		206
#define RECEV_ERR			207
#define NETWORK_ERR			208
#define WRITE_ERR			209
#define NETWORK_BREAK		210
#define CORE_BREAK			211

#endif