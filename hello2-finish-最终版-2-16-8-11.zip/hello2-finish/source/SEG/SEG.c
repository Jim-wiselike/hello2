#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/prctl.h>
#include <errno.h>

#include "initialize.h"
#include "mp4Segment.h"
#include "SEG.h"

__asm__(".symver memcpy,memcpy@GLIBC_2.2.5");
int client_fd;
unsigned char *monitor=NULL;

extern int msgid;

fun_names plugin()
{
	fun_names a=get_argv(2, "SEG_MAIN", "SEG_WRITE");
	return a;
}

int pushdate(unsigned char *cmd_buf, int size)
{
	struct msgbuf msg;
	int r=0;
	bzero(msg.data,sizeof(msg.data));
	msg.type=888;
	memcpy(msg.data, cmd_buf, size);
	msgsnd(msgid, &msg, size, 0);
	msgrcv(msgid,&msg,26,999,0);
	r=send(client_fd, msg.data, 26, 0);
	if(r<1)
	{
		plog(4, "Send info TIME OUT! Close the socket!\r\n");
		close(client_fd);
		client_fd=-1;
		return 0;
	}
	if(msg.data[1]==0X64 || msg.data[1]==0XFF)
	{
		plog(3, "Segment(Raw data): %02X %.*s\r\n", msg.data[1], 24, msg.data+2);
		return 1;
	}
	else return 0;
}

void chkdate(unsigned char *cmd_buf, int r)
{
	unsigned char *buf = cmd_buf;
	int size=0, i;
	static int flag=1;
	for(i=0; i<=cmd_buf[1]; i++)
	{
		if( buf==cmd_buf ) size = 50;
		else size += buf[1] ;
		if( size>1500 ) break;
		buf = cmd_buf+size;
	}
	if( size==r )
	{
		if( !flag ) 
		{
			cmd_buf[1]=0;
			size = 50;
		}
		else plog(0, "chkdate finish send to execute!\r\n");
		flag=pushdate(cmd_buf, size);
	}
	else
	{
		plog(4, "Chkd %d bytes of packet !!! The Packet is not complete!\r\n", size);
		return;
	}
}

int segmain()
{
	int server_fd;
	int r ;

	unsigned char cmd_buf[BUFF_SIZE];
	struct sockaddr_in server_addr = {0};
	struct sockaddr_in client_addr = {0};
	socklen_t len;
	int opt = SO_REUSEADDR;
	struct timeval timeout;

	plog(6, "\r\n------------------------SEG new start------------------------\r\n" );
//start socket
	server_fd=socket( AF_INET,SOCK_STREAM ,6 );
	if ( server_fd==-1 )
	{
		close( server_fd );
		plog (1, "socket err:%s\r\n", strerror(errno));
		return;
	}
	
	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
//bind&listen
	server_addr.sin_family = AF_INET;
	server_addr.sin_port   = htons( SERVER_PROT );
	server_addr.sin_addr.s_addr=htonl(INADDR_ANY); 
	r = bind(server_fd, (struct sockaddr*) &server_addr, sizeof(server_addr));
	if( r==-1 )
	{
		close( server_fd );
		plog (1, "bind err:%s\r\n", strerror(errno));
		return;
	}

	r = listen( server_fd , 2 );
	if( r==-1 )
	{
		close( server_fd);
		plog (1, "listen err:%s\r\n", strerror(errno));
		return;
	}
	else plog(0,"Port:%d\tListenning!\r\n", SERVER_PROT);
	
	
//accept client
while(1)
{
	len = sizeof( client_addr );
	client_fd = accept( server_fd, (struct sockaddr*) &client_addr, &len );
	if( client_fd==-1 )
	{
		close( client_fd );
		plog (1, "accept err:%s\r\n", strerror(errno));
		continue;//break;
	}
	else
	{
		plog(3, "JT-WEBS connected:%d,ip:%s:%u\r\n" ,
				client_fd,								//num
				inet_ntoa( client_addr.sin_addr ),		//show ip
				ntohs(client_addr.sin_port) );			//show port number
	}
	timeout.tv_sec = 10; 
	timeout.tv_usec = 0;
	setsockopt(client_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(struct timeval));
	setsockopt(client_fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(struct timeval));
	while(1)
	{
	//recv commend packege
		bzero(cmd_buf, sizeof(cmd_buf));
		if(client_fd>0) r=recv(client_fd, cmd_buf ,1500 , 0);
		else r=-1;
		if ( r==-1 || r==0 || cmd_buf[0]!=WEB_TO_DRS_HEAD )
		{
			if( r==-1 || r==0 )
			{
				if(errno==EINTR) continue;
				plog(3, "JT-WEBS break the socket automatically.Break code:%d, strerror=%s\r\n", r, r==-1?strerror(errno):"NULL");
				break;
			}
			else 
			{
				plog(4, "JT-WEBS send error cmd:\tHEAD=%c(%d)\tr=%d\t\r\n", cmd_buf[0], cmd_buf[0], r);
				continue;
			}
		}
		else
		{
			if( r==2 )
			{
				send(client_fd, "F", 1, 0);
				continue;
			}
			chkdate(cmd_buf, r);
		}
	}
//finish
	close ( client_fd );
}
	close( server_fd );
	plog (1, "drsmain core break!!!\r\n" );
	return;
}

void SEG_MAIN()
{
	char ads[50];
	int r=0;
	int id=6;
	prctl(PR_SET_NAME, "SEG-MAIN", NULL, NULL, NULL);
	get_path("[SEG-LOG]", "/var/log/drs8/SEG", ads, &id);
	if( init_LOG(msgid, id, ads, "[SEG-MAIN]") )
		plog(4, "init LOG error. This is [SEG-MAIN]!!!\r\n");

	if( r=free_space(ads) ){
			plog(4, "Disk is FULL(%dMB available)!!!\r\n", r-1);
			plog(3, "SEGMENT service CLOSED!!!\r\n");
			sleep(3600);
			return;
	}
	
	while( msg_init(&msgid, 201)>0)
	{
		plog(4, "Msg for connecting with SEG-EXECUTE err!\r\n");
		sleep(10);
	}
	segmain();
}

void SEG_WRITE()
{	
	char log[5];
	sprintf(log, "%d", msgid);
	execl("./plugin/SEG-EXECUTE","SEG-EXECUTE", log, NULL);
}