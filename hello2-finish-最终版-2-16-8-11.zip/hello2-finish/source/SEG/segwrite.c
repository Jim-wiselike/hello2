﻿/*---------------------------------------------------------------------------
; 	Copyright (C) 2014 Fun Class
; 	All rights reserved.
;
;
; 	FILE NAME  	: SEGWRITE.C 
; 	DESCRIPTION	: video clips 
; 	Author		: Jim
; 	REVISION 1.0 
;
;---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <pthread.h>

#include "SEG.h"
#include "mp4Segment.h"
#include "initialize.h"

char address[255];
char address_mp4[255];
List list={0};
int msgid=0;

void add(struct List* l, struct queue new)
{
	struct queue* head = l->head;
	struct queue* a=(struct queue*)malloc(sizeof(struct queue));
	*a = new;
	a->next = NULL;
	if(l->head == NULL)
	{
		l->head = a;
		l->end = a;
		l->num=1;
		return;
	}
	while(head->next!=NULL)
	{
		head = head->next;
	}
	head->next = a;
	l->end = a;
	l->num++;
}

void del(struct List* l)
{
	struct queue* head = l->head;
	l->head = head->next;
	free(head);
	l->num--;
}

char* msg_chk(unsigned char *cmd_buf, int l)
{
	unsigned char fname[25];
	static unsigned char send_buf[26]="F"; 
	memcpy(fname, cmd_buf+26, 24); fname[24]=0;
	if(l==50)
	{
		if(list.head==NULL)
		{
			send_buf[1] = 0xFF;
			memcpy(send_buf+2, cmd_buf+26, 24);
		}
		else if(!strcmp(list.head->file, fname))
		{
			send_buf[1] = list.head->stat;
			sprintf(send_buf+2, "%s", list.head->file);
			if(send_buf[1]==0X64 || send_buf[1]==0XFF)
				del(&list);
		}
		else
		{
			plog(4, "File err!");
			send_buf[1] = list.head->stat;
			sprintf(send_buf+2, "%s", list.head->file);
		}
		return send_buf;
	}
	queue new;
	sprintf(new.file, "%s", fname);
	memcpy(new.file_from, cmd_buf+2, 24); new.file_from[24]=0;
	memcpy(new.cmd, cmd_buf, l);
	new.stat=0;
	add(&list, new);
	plog(0, "New mission added.\r\n");
	send_buf[1] = list.head->stat;
	sprintf(send_buf+2, "%s", list.head->file);
	return send_buf;
}

void* segwrite(void* cp)
{
	int i;
	int flag = 0;
	int p=50;
	ClipFrames cf={0};
	
	pthread_detach(pthread_self());
	plog(0, "Pthread_create success.\r\n");
	unsigned char mp4_tep[255];
	unsigned char mp4[255];
	sprintf(mp4    ,"%s%s"     , address, list.head->file_from );
	sprintf(mp4_tep, "%s%s.mp4", address_mp4, list.head->file);

	plog(0, "%d Command analyzed for this mission!\r\n", list.head->cmd[1]);
	while( list.head->cmd[1]-- )
	{
		switch( list.head->cmd[p] )
		{
			case 0x01:
			{
				i = (list.head->cmd[p+1]-2) /16;
				cf.clipFrameCount = i;
				while( i-- )
				{
					cf.clipframe[i].mindts=(int64_t)list.head->cmd[p+2+ i*16   ]<<56 | (int64_t)list.head->cmd[p+2+ i*16 +1]<<48
										  |(int64_t)list.head->cmd[p+2+ i*16 +2]<<40 | (int64_t)list.head->cmd[p+2+ i*16 +3]<<32
										  |(int64_t)list.head->cmd[p+2+ i*16 +4]<<24 | (int64_t)list.head->cmd[p+2+ i*16 +5]<<16
										  |(int64_t)list.head->cmd[p+2+ i*16 +6]<<8  | (int64_t)list.head->cmd[p+2+ i*16 +7];
					cf.clipframe[i].maxdts=(int64_t)list.head->cmd[p+2+ i*16 +8]<<56 | (int64_t)list.head->cmd[p+2+ i*16 +9]<<48
										  |(int64_t)list.head->cmd[p+2+ i*16 +10]<<40 | (int64_t)list.head->cmd[p+2+ i*16 +11]<<32
										  |(int64_t)list.head->cmd[p+2+ i*16 +12]<<24 | (int64_t)list.head->cmd[p+2+ i*16 +13]<<16
										  |(int64_t)list.head->cmd[p+2+ i*16 +14]<<8  | (int64_t)list.head->cmd[p+2+ i*16 +15];
					plog(0, "Command%d:mindts=%lld, maxdts=%lld\r\n", (list.head->cmd[p+1]-2) /16-i, cf.clipframe[i].mindts, cf.clipframe[i].maxdts);
				}
				if( access(mp4, F_OK)!=0 )
				{
					sprintf(mp4+strlen(mp4)-3, "mp4");
				}
				if( access(mp4, F_OK)!=0 )
				{
					sprintf(mp4+strlen(mp4)-3, "MP4");
				}
				if( mp4_Segment(mp4, mp4_tep, cf, &list.head->stat) ) flag=1;
				else flag=0;
				break;
			}
			
			default:plog(4, "Unknow cmd:%d, p=%d\r\n",  list.head->cmd[p], p);
		}
		if( flag ) 
		{
			plog(4, "mp4_Segment(%s-->%s) err!\r\n", mp4, mp4_tep);
			unlink( mp4_tep );
			break;
		}
		else
		{
//			if( unlink(mp4)==-1 )plog(4, "unlink source-file(%s) err:%s\r\n", mp4, strerror(errno));
			sprintf(mp4, "%s", mp4_tep);
			mp4[strlen(mp4_tep)-4]=0;
			rename(mp4_tep, mp4);
			plog(3, "mp4_Segment(%s) successfully!\r\n", mp4);
		}
		p += list.head->cmd[p+1];
	}
	if(flag)list.head->stat = 0xFF;
	else list.head->stat = 0x64;
//	del(&list);
	plog(0, "Pthread exit!\r\n");
}

void segmain()
{
	unsigned char* cmd_buf;
	int r;
	pthread_t seg;
	struct msgbuf msg;
	int i=0;
	
	while(1)
	{
		r=msgrcv(msgid,&msg,sizeof(msg.data),888,0);
		if(r==50)
		{
			i++;
			if(i%20==0) plog(0, "Task check received by msg! *20 times!\r\n");
		}
		else
		{
			if(i>0) plog(0, "Task check received by msg! Total:*%d times!\r\n", i);
			i=0;
			plog(0, "New task received! %dBytes by msg.\r\n", r);
		}
		cmd_buf = msg_chk(msg.data, r);
		bzero(msg.data,sizeof(msg.data));
		msg.type=999;
		memcpy(msg.data, cmd_buf, 26);
		msgsnd(msgid, &msg, 26, 0);
		if(r>50 && list.num==1)
		{
			plog(0, "Task%s-->%s\r\n", list.head->file_from, list.head->file);
			r = pthread_create(&seg, NULL, &segwrite, (void*)NULL);
			usleep(1);
			if (r != 0)
			{
				plog(4, "Pthread  create error:%m(%s-->%s)\r\n", list.head->file_from, list.head->file);
			}
		}

	}
}

void main(int argc, char** argv)
{
	char ads[50];
	int id=6;
	msgid=atoi(argv[1]);
	printf("SEG-EXECUTE:\targc=%d, argv[1]=%d\r\n", argc, msgid);
	get_path("[SEG-LOG]", "/var/log/drs8/SEG", ads, &id);
	init_LOG(msgid, id, ads, "[SEG-EXECUTE]");
	
	if(free_space(ads)){
			sleep(3600);
			return;
	}
	
	while( msg_init(&msgid, 201)>0)
	{
		plog(4, "Msg for connecting with SEG-MAIN err!\r\n");
		sleep(10);
	}
	plog(0, "Program Start!!!\r\n");
	
	get_path("[MP4-ADDRESS]", "/var/sourceroot/", address, NULL);
	get_path("[MP4-CUT-ADDRESS]", "/var/sourceroot/", address_mp4, NULL);
	plog(0, "MP4(old) file address:%s\r\n", address);
	plog(0, "MP4(new) file address:%s\r\n", address_mp4);
	CreateDirectoryEx(address);
	CreateDirectoryEx(address_mp4);
	
	segmain();
}
