﻿/*---------------------------------------------------------------------------
; 	Copyright (C) 2014 Fun Class
; 	All rights reserved.
;
;
; 	FILE NAME  	: MP4SEGMENT.C 
; 	DESCRIPTION	: segment program
; 	Author		: D
; 	REVISION 1.0 
;
;---------------------------------------------------------------------------*/

#ifdef	__cplusplus
#include "stdafx.h"
#else
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libavutil/avstring.h>
#endif

#include "mp4Segment.h"
#include "initialize.h"

#define MAX_STREAM_NUM  10
#define decodeMp4  0

typedef struct st_StreamMapping
{
	enum AVMediaType type;
	int output_index;
	int64_t offset;
	int64_t nextdts;
} StreamMapping;


static int avformatcxt_alloc(AVFormatContext **avctx, const char *filename)
{
    AVFormatContext *s = avformat_alloc_context();
	//AVOutputFormat *oformat = av_guess_format("mp4", NULL, NULL);
	AVOutputFormat *oformat = av_guess_format(NULL, filename, NULL);
    int ret = 0;

    *avctx = NULL;
    if (!s)
        goto nomem;

    s->oformat = oformat;
    if (s->oformat->priv_data_size > 0) {
        s->priv_data = av_mallocz(s->oformat->priv_data_size);
        if (!s->priv_data)
            goto nomem;
        if (s->oformat->priv_class) {
            *(const AVClass**)s->priv_data= s->oformat->priv_class;
            av_opt_set_defaults(s->priv_data);
        }
    } else
        s->priv_data = NULL;

    if (filename)
    {
        av_strlcpy(s->filename, filename, sizeof(s->filename));
	}
    *avctx = s;
    return 0;
	
nomem:
    av_log(s, AV_LOG_ERROR, "Out of memory\r\r\n");
    ret = AVERROR(ENOMEM);

    avformat_free_context(s);
    return ret;
}

int64_t lastdts(int64_t dts, ClipFrames clipframes)
{
	int i;
	for (i=0; i<clipframes.clipFrameCount; i++)
	{
		if ((dts>=clipframes.clipframe[i].mindts) && (dts<clipframes.clipframe[i].maxdts))
		{
			return clipframes.clipframe[i].maxdts;
		}
	}
	return dts;
}

int mp4_Segment(char *src_filename, char *dest_filename, ClipFrames clipframes, int *mp4_Segment_pec)
{
	*mp4_Segment_pec=1;

	AVOutputFormat *ofmt = NULL;
	AVInputFormat *ifmt = NULL;
    AVFormatContext *ifmt_ctx = NULL, *ofmt_ctx = NULL;
	AVBitStreamFilterContext *bsfc = NULL;
    AVPacket pkt, out_pkt;
	StreamMapping map_table[MAX_STREAM_NUM];
	int ret = 0, i, output_index = 0, init_keyframe = 0;
	AVCodecContext *dec_ctx, *enc_ctx;
	AVCodec *decoder, *encoder; 

	//set log level
	av_log_set_level(AV_LOG_FATAL);

    if (!src_filename || !dest_filename) {
        plog(4, "mp4_Segment: input filename or output filename is null.\r\n");
        return 1;
    }

	avcodec_register_all();
    av_register_all();
	
	if ((ret = avformat_open_input(&ifmt_ctx, src_filename, NULL, NULL))<0)
	{
		plog(4, "mp4_Segment: cannot open sourcefile '%s'.\r\n", src_filename);
		return 1;
	}

	if ((ret = avformat_find_stream_info(ifmt_ctx, NULL))<0)
	{
		plog(4, "mp4_Segment: cannot open find source streams.\r\n");
		return 1;
	}

	av_dump_format(ifmt_ctx, 0, src_filename, 0);
	ifmt=ifmt_ctx->iformat;
	
	avformatcxt_alloc(&ofmt_ctx, dest_filename);
	if (!ofmt_ctx) {
		plog(4, "Could not create output context\r\n");
		ret = AVERROR_UNKNOWN;
		goto end;
	}

	ofmt = ofmt_ctx->oformat;

	if ( ifmt_ctx->nb_streams > MAX_STREAM_NUM ) {
		plog(4, "Too many stream number %d in input stream.\r\n", ifmt_ctx->nb_streams);
        goto end;
	}
	
	for (i=0; i<ifmt_ctx->nb_streams; i++)
	{
		AVStream *in_stream = ifmt_ctx->streams[i];
		AVStream *out_stream = NULL;

		map_table[i].type = in_stream->codec->codec_type;
		map_table[i].output_index = MAX_STREAM_NUM;
		map_table[i].nextdts= 0;

		if ( in_stream->codec->codec_type != AVMEDIA_TYPE_VIDEO && in_stream->codec->codec_type != AVMEDIA_TYPE_AUDIO)
			continue;

		map_table[i].output_index = output_index++;
		
		out_stream = avformat_new_stream(ofmt_ctx, in_stream->codec->codec);
		if (!out_stream) {
			plog(4, "Failed allocating output stream\r\n");
			ret = AVERROR_UNKNOWN;
			goto end;
		}

		ret = avcodec_copy_context(out_stream->codec, in_stream->codec);
		if (ret < 0) {
			plog(4, "Failed to copy context from input to output stream codec context\r\n");
			goto end;
		}
		if (ofmt_ctx->oformat->flags & AVFMT_GLOBALHEADER)
			out_stream->codec->flags |= CODEC_FLAG_GLOBAL_HEADER;

		out_stream->codec->codec_tag=0;
		out_stream->codec->time_base = in_stream->time_base;
		//out_stream->codec->sample_aspect_ratio.num=2;
		//out_stream->codec->sample_aspect_ratio.den=3;

		if ((in_stream->codec->codec_type == AVMEDIA_TYPE_VIDEO)&&(decodeMp4 == 1))
		{
			AVCodecContext *dec_ctx; 
			dec_ctx = in_stream->codec; 
			decoder = avcodec_find_decoder(dec_ctx->codec_id);
			ret =avcodec_open2(dec_ctx, decoder, NULL); 
			if (ret < 0) { 
				av_log(NULL, AV_LOG_ERROR, "Failed toopen decoder for stream #%u\r\n", i); 
				goto end;
			}
			enc_ctx=out_stream->codec;
			enc_ctx->level=30;
			enc_ctx->qmin = 3;
			enc_ctx->qmax = 32;
			encoder= avcodec_find_encoder(enc_ctx->codec_id); 
			ret =avcodec_open2(enc_ctx, encoder, NULL); 
			if (ret < 0) { 
				av_log(NULL, AV_LOG_ERROR, "Cannot openvideo encoder for stream #%u\r\n", i); 
				goto end;
			} 
		}
	}

	bsfc = av_bitstream_filter_init("aac_adtstoasc");

    if (!(ofmt->flags & AVFMT_NOFILE)) {
        ret = avio_open(&ofmt_ctx->pb, dest_filename, AVIO_FLAG_WRITE);
        if (ret < 0) {
            plog(4, "Could not open output file '%s'", dest_filename);
            goto end;
        }
	}

    ret = avformat_write_header(ofmt_ctx, NULL);
    if (ret < 0) {
		plog(4, "Error occurred when opening output file\r\n");
		av_log(ofmt_ctx, AV_LOG_ERROR, "Out of memory\r\n");
        goto end;
    }

	int frameFinished;
	AVFrame *pFrame;
	pFrame =av_frame_alloc();
	AVRational timebase;
	int64_t durations=0;
	
	//av_seek_frame(ifmt_ctx, videoid, 1491020808, AVSEEK_FLAG_BACKWARD);
	//av_seek_frame(ifmt_ctx, 1491420808, NULL )

    while (1) {
        AVStream *in_stream, *out_stream;

        ret = av_read_frame(ifmt_ctx, &pkt);
        if (ret < 0)
            break;

        in_stream  = ifmt_ctx->streams[pkt.stream_index];
        out_stream = ofmt_ctx->streams[map_table[pkt.stream_index].output_index];

        // skip non-key video frame 
        if (!init_keyframe){
            if ((map_table[pkt.stream_index].type == AVMEDIA_TYPE_VIDEO) && (pkt.flags & AV_PKT_FLAG_KEY)){
                init_keyframe = 1;
				timebase=out_stream->time_base;
            }
            else{
                av_free_packet(&pkt);
                continue;
            }
		}

		if (map_table[pkt.stream_index].type == AVMEDIA_TYPE_VIDEO)
		{	
			int64_t ndts=lastdts(pkt.dts, clipframes);
			if (ndts>pkt.dts)
			{
				ret = av_seek_frame(ifmt_ctx, pkt.stream_index, ndts, AVSEEK_FLAG_ANY);
				if (ret < 0)
					break;
				init_keyframe=0;
				continue;
			}
			if (pkt.flags & AV_PKT_FLAG_KEY)
			{
				int64_t dts=pkt.dts;
				plog(4,  "%f", dts/1.0);			
			}
			durations +=pkt.duration;
		}
		
		pkt.pts += map_table[pkt.stream_index].nextdts - pkt.dts;
		pkt.dts = map_table[pkt.stream_index].nextdts;

        // copy packet 
		if ((in_stream->time_base.den!=out_stream->time_base.den)&&(in_stream->time_base.num!=out_stream->time_base.num))
		{
			pkt.pts = av_rescale_q_rnd(pkt.pts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.dts = av_rescale_q_rnd(pkt.dts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.duration = av_rescale_q(pkt.duration, in_stream->time_base, out_stream->time_base);
		}
		if (pkt.duration<0 )
			pkt.duration=0;
        pkt.pos = -1;	



		if ((map_table[pkt.stream_index].type == AVMEDIA_TYPE_VIDEO)&&(decodeMp4 == 1))
		{
			ret = avcodec_decode_video2(in_stream->codec, pFrame, &frameFinished, &pkt);
			if (ret < 0) // if error len = -1
			{
				plog(4, "Error in decoding video frame.\r\n");
			}

			char *bmpfilename = "E:\\1.BMP";
			SaveAsBMP(in_stream->codec, pFrame, bmpfilename, 24);

			av_init_packet(&out_pkt); 
			out_pkt.data = NULL;    // packet data will be allocated by the encoder 
			out_pkt.size = 0;

			int y_size = out_stream->codec->width * out_stream->codec->height;
			ret = av_new_packet(&out_pkt,y_size*3);
			ret = avcodec_encode_video2(out_stream->codec, &out_pkt, pFrame, &frameFinished);
			if(ret < 0)
			{
				plog(4, "编码错误！\r\n");
				return -1;
			}
			out_pkt.dts=pkt.dts;
			out_pkt.pts=pkt.pts;
			out_pkt.duration=pkt.duration;
		} 
		else
		{
			out_pkt = pkt;
		}



        /*out_pkt = pkt;*/
		out_pkt.stream_index = map_table[pkt.stream_index].output_index;
		map_table[pkt.stream_index].nextdts = pkt.dts+pkt.duration;

        // process AAC packet 
        if (in_stream->codec->codec_id == AV_CODEC_ID_AAC){
			int a = av_bitstream_filter_filter(bsfc, out_stream->codec, NULL, &out_pkt.data, &out_pkt.size, pkt.data, pkt.size, pkt.flags & AV_PKT_FLAG_KEY);
        }

        ret = av_interleaved_write_frame(ofmt_ctx, &out_pkt);
        if (ret < 0) {
            plog(4, "Error muxing packet\r\n");
            break;
		}

        //av_free_packet(&pkt);
    }

    ret = av_write_trailer(ofmt_ctx);
	*mp4_Segment_pec=100;

end:

    avformat_close_input(&ifmt_ctx);

    /* close output */
    if (ofmt_ctx && !(ofmt->flags & AVFMT_NOFILE))
        avio_close(ofmt_ctx->pb);
    avformat_free_context(ofmt_ctx);

    if (bsfc)
	    av_bitstream_filter_close(bsfc);

    if (ret < 0 && ret != AVERROR_EOF) {
        plog(4, "Error occurred: %d\r\n", ret);
        return 1;
    }

    return 0;
}

