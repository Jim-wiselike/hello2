#ifndef _LOG_H_
#define _LOG_H_

typedef struct log_qu{
	int id;
	char path[FILE_PATH_L];
	struct log_qu* next;
}log_qu;

typedef struct path_save{
	char* path;
	struct path_save* next;
}path_save;

typedef struct msg_add{
	int id;
	char path[FILE_PATH_L];
}msg_add;

int CreateDirectoryEx(char *sPathName);
void* pthread(void* cp)	;
int msg_init(int* msgid, int cp);
void msg_recv(int msgid, msg_buf* mbuf);


#endif 
