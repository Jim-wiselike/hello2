﻿#ifndef _TS_H
#define _TS_H 1

#define SERVER_PROT			9966
#define WEB_TO_DRS_HEAD		'W'
#define DRS_TO_WEB_HEAD		'D'

//error define



#define TSWRITE_PROT		5223
#define BUF_SIZE_T 			32768
#define SIGNAL_PAKG_SIZE	20

#define UNIX_PATH_MAX 108

typedef struct cmd_pakg{
	unsigned char cmd_chan;						//命令号
	unsigned char file[20];						//时间
	unsigned int ip_addr;						//ip地址
}cmd_pakg;

typedef struct stream_cmd_pakg{
	unsigned char chan;						//命令号
	unsigned char cmd;						//时间
	unsigned int ip_addr;						//ip地址
	unsigned int port;
}stream_cmd_pakg;

struct msgbf
{
	long type;
	char data[255];
};

#define CODER_ERROE			200
#define SOCKET_ERR			201
#define BIND_ERR			202
#define LISTEN_ERR			203
#define CONNECT_ERR			204
#define ACCEPT_ERR			205
#define FILE_CREAT_ERR		206
#define RECEV_ERR			207
#define NETWORK_ERR			208
#define WRITE_ERR			209
#define NETWORK_BREAK		210
#define CORE_BREAK			211
#define TIME_UP				212


#endif
