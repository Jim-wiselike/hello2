﻿/*---------------------------------------------------------------------------
; 	Copyright (C) 2001 Fun Class
; 	All rights reserved.
;
;
; 	FILE NAME  	: TS2MP4.C 
; 	DESCRIPTION	: Using for transforming from ts to mp4 files.
; 	Author		: Jim
; 	REVISION 1.0 
;
;---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>

#include "initialize.h"
#include "TS.h"

int msgid=0;
unsigned char *monitor=NULL;
int ts2mp4_transform(char *ts_filename, char *mp4_filename, int* ts2mp4_transform_pec);

void state_init(void)
{
	int fd;
	fd=open("tmp_dat",O_RDWR|O_CREAT|O_EXCL,0666);
	if(fd==-1)
	{
		fd=open("tmp_dat",O_RDWR);
	}
	ftruncate(fd, 256);
	monitor = mmap(0, 256, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
	monitor[0]='D';
	close(fd);
}

unsigned long get_file_size(const char *path)
{
    unsigned long filesize = -1;
    struct stat statbuff;
    if(stat(path, &statbuff) < 0)
        return filesize;
    else filesize = statbuff.st_size;
    return filesize;
}

char* create_add(char* add, char* old_add)
{
	int l=strlen(old_add);
	int al = strlen(add);
	while(--l)
	{
		if( old_add[l] == '/' )break;
	}
	sprintf(add+al, "%s", old_add+l);
	return add;
}

void main(int argc, char** argv)
{	
	char ads[50];
	char address[255];
	int r=0;
	int id=5;
	msgid=atoi(argv[1]);
	printf("TS2MP4:\targc=%d, argv[1]=%d\r\n", argc, msgid);
	struct msgbf msg;
	char mp4_tep[255]={0},mp4_filename[255]={0};
	get_path("[TS-LOG]", "/var/log/drs8/TS", ads, &id);
	init_LOG(msgid, id, ads, "[TS2MP4]");
	
	if(free_space(ads) ){
			sleep(3600);
			return;
	}
	
	while( msg_init(&msgid, 200)>0)
	{
		plog(4, "Msg for connecting with TS-WRITE err!\r\n");
		sleep(10);
	}
	state_init();
	plog(0, "Program Start!!!\r\n");
	while(1)
	{
		plog(3, "Prepared for a new transform.\r\n");
		bzero(&msg,sizeof(msg));
		r=msgrcv(msgid,&msg,sizeof(msg.data),777,0);
		if(r==-1)
		{
			plog(4, "msg recv TS-file error!!! %s\r\n", strerror(errno));
			continue;
		}
		else plog(0, "msg recv %d datas for TS-file:%s\r\n", r, msg.data);

		sprintf(mp4_tep, "%s.tep", msg.data);
		if (ts2mp4_transform(msg.data, mp4_tep, &r))//r is a temp-var
		{
			plog(4, "Error: call ts2mp4_transform error!\r\n");
			if( unlink(mp4_tep)==-1 )plog(4, "unlink mp4-tep-file(%s) err:%s\r\n", mp4_tep, strerror(errno));
			else plog(0, "unlinked tmp file:%s\r\n", mp4_tep);
		}
		else
		{
			plog(3, "Transform successfully\r\n");
			memcpy(mp4_filename, mp4_tep, 255);
			sprintf(mp4_filename+strlen(mp4_tep)-7, ".MP4");
			if( rename(mp4_tep, mp4_filename)==-1 )plog(4, "rename ts-tmp(%s) err:%s\r\n", mp4_tep, strerror(errno));
			else
			{
				if( get_file_size(mp4_filename)>1024*10 )
				{
					if( unlink(msg.data)==-1 )plog(4, "unlink TS-file(%s) err:%s\r\n", msg.data, strerror(errno));
				}
				else
					plog(4, " MP4-file(%s)'s size(%d)<10Kb is TOO small! TS-file undeleted.\r\n", mp4_filename, get_file_size(mp4_filename));
				
				get_path("[MP4-ADDRESS]", "/var/sourceroot/", address, NULL);
				if( rename(mp4_filename, create_add(address, mp4_filename) )==-1 )
					plog(4, "move mp4-tmp(%s)->(%s) err:%s\r\n", mp4_filename, address,strerror(errno));
			}
		}
	}
}
