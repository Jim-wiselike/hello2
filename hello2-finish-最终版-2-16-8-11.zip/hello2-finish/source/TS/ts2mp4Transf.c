﻿/*---------------------------------------------------------------------------
; 	Copyright (C) 2014 Fun Class
; 	All rights reserved.
;
;
; 	FILE NAME  	: TS2MP4TRANSF.C 
; 	DESCRIPTION	: Using for transforming ts files to mp4 files 
; 	Author		: D
; 	REVISION 1.0 
;
;---------------------------------------------------------------------------*/

#ifdef	__cplusplus
#include "stdafx.h"
#else
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libavutil/avstring.h>
#include <libavutil/avstring.h>
#include <libavutil/timestamp.h>
#endif


#include "initialize.h"


#define MAX_STREAM_NUM  10
#define true 1
#define false 0


typedef struct st_StreamMapping
{
	enum AVMediaType type;
	int output_index;
} StreamMapping;


static int avformatcxt_alloc(AVFormatContext **avctx, const char *filename)
{
    AVFormatContext *s = avformat_alloc_context();
	//AVOutputFormat *oformat = &ff_mov_muxer;
	//AVOutputFormat *oformat = av_guess_format("mpeg", NULL, NULL);
	AVOutputFormat *oformat = av_guess_format(NULL, "1.MP4", NULL);
    int ret = 0;

    *avctx = NULL;
    if (!s)
        goto nomem;

    s->oformat = oformat;
    if (s->oformat->priv_data_size > 0) {
        s->priv_data = av_mallocz(s->oformat->priv_data_size);
        if (!s->priv_data)
            goto nomem;
        if (s->oformat->priv_class) {
            *(const AVClass**)s->priv_data= s->oformat->priv_class;
            av_opt_set_defaults(s->priv_data);
        }
    } else
        s->priv_data = NULL;

    if (filename)
        av_strlcpy(s->filename, filename, sizeof(s->filename));
    *avctx = s;
    return 0;
	
nomem:
    //av_log(s, AV_LOG_ERROR, "ts2mp4_transform: Out of memory.\r\n");
    ret = AVERROR(ENOMEM);

    avformat_free_context(s);
    return ret;
}

int ts2mp4_transform(char *ts_filename, char *mp4_filename, int* ts2mp4_transform_pec)	//aac,h264
{
//	*ts2mp4_transform_pec=1;

	AVOutputFormat *ofmt = NULL;
	AVFormatContext *ifmt_ctx = NULL, *ofmt_ctx = NULL;
	AVInputFormat *iformat = NULL;
	AVBitStreamFilterContext *bsfc = NULL;
    AVPacket pkt, out_pkt;
	StreamMapping map_table[MAX_STREAM_NUM];
    int ret = 0, i, output_index = 0, init_keyframe = 0, videototaldur=0;
	AVRational vtimebase;
	AVRational atimebase;

	//set log level
	av_log_set_level(AV_LOG_FATAL);

    if (!ts_filename || !mp4_filename) {
        plog(1, "ts2mp4_transform: input filename or output filename is null.\r\n");
				ret = -10;
        return 1;
    }

	av_register_all();

	//iformat = &ff_mpegts_demuxer;

	if ((ret = avformat_open_input(&ifmt_ctx, ts_filename, NULL, NULL))<0)
	{
        plog(1, "ts2mp4_transform: Could not open input file '%s'.\r\n", ts_filename);
        ret = -10;
        goto end;
	}

	if ((ret = avformat_find_stream_info(ifmt_ctx, NULL))<0)
	{
        plog(1, "ts2mp4_transform: Failed to retrieve input streams information.\r\n");
		ret = -10;
        goto end;
	}

	av_dump_format(ifmt_ctx, 0, ts_filename, 0);

    avformatcxt_alloc(&ofmt_ctx, mp4_filename);
    if (!ofmt_ctx) {
        plog(1, "ts2mp4_transform: Could not create output context.\r\n");
        ret = AVERROR_UNKNOWN;
        goto end;
	}

	ofmt = ofmt_ctx->oformat;

	if ( ifmt_ctx->nb_streams > MAX_STREAM_NUM ) {
		plog(1, "ts2mp4_transform: Too many stream number %d in input streams.\r\n", ifmt_ctx->nb_streams);
		ret = -10;
		goto end;
	}

	int videostream=false;
    for (i = 0; i < ifmt_ctx->nb_streams; i++) {
        AVStream *in_stream = ifmt_ctx->streams[i];
        AVStream *out_stream = NULL;

		map_table[i].type = in_stream->codec->codec_type;
		map_table[i].output_index = MAX_STREAM_NUM;

		if ( in_stream->codec->codec_type != AVMEDIA_TYPE_VIDEO && in_stream->codec->codec_type != AVMEDIA_TYPE_AUDIO)
			continue;
		if (in_stream->codec->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			videototaldur=in_stream->duration;	
			videostream=true;
			vtimebase=ifmt_ctx->streams[i]->time_base;
		}
		else if (in_stream->codec->codec_type == AVMEDIA_TYPE_AUDIO)
		{	
			atimebase=ifmt_ctx->streams[i]->time_base;
		}
		map_table[i].output_index = output_index++;

		out_stream = avformat_new_stream(ofmt_ctx, in_stream->codec->codec);
        if (!out_stream) {
            plog(1, "ts2mp4_transform: Failed allocating output stream.\r\n");
            ret = AVERROR_UNKNOWN;
            goto end;
        }
				
        ret = avcodec_copy_context(out_stream->codec, in_stream->codec);
        if (ret < 0) {
            plog(1, "ts2mp4_transform: Failed to copy context from input to output stream codec context.\r\n");
            goto end;
        }
        if (ofmt_ctx->oformat->flags & AVFMT_GLOBALHEADER)
            out_stream->codec->flags |= CODEC_FLAG_GLOBAL_HEADER;

		out_stream->codec->codec_tag=0;
		out_stream->codec->time_base = in_stream->time_base;
		//out_stream->codec->level=30;
		//out_stream->codec->sample_aspect_ratio.num=2;
		//out_stream->codec->sample_aspect_ratio.den=3;
    }
	if (videostream==false)
	{
		plog(1, "ts2mp4_transform: Cannot find video stream.\r\n");
		ret=-10;
		goto end;
	}

	/* initialize filter */
	/*
	bsfc =(AVBitStreamFilterContext*) av_mallocz(sizeof(AVBitStreamFilterContext));
	if (!bsfc){
		fprintf(stderr, "Failed to init bitstream filter\n");
		goto end;
	}
    bsfc->filter    = &ff_aac_adtstoasc_bsf;
    bsfc->priv_data = av_mallocz(ff_aac_adtstoasc_bsf.priv_data_size);
	*/
	bsfc = av_bitstream_filter_init("aac_adtstoasc");

    if (!(ofmt->flags & AVFMT_NOFILE)) {
        ret = avio_open(&ofmt_ctx->pb, mp4_filename, AVIO_FLAG_WRITE);
        if (ret < 0) {
            plog(1, "ts2mp4_transform: Could not open output file '%s'.\r\n", mp4_filename);
            ret = -10;
            goto end;
        }
    }
	
    ret = avformat_write_header(ofmt_ctx, NULL);
    if (ret < 0) {
        plog(1, "ts2mp4_transform: Error occurred when opening output file.\r\n");
        ret = -10;
        goto end;
    }
	
	int64_t audiopts=0;
	int64_t videopts=0;
	int64_t offset=AV_NOPTS_VALUE;
    while (1) {
        AVStream *in_stream, *out_stream;

        ret = av_read_frame(ifmt_ctx, &pkt);
        if (ret < 0)
            break;
		if (pkt.stream_index>ifmt_ctx->nb_streams-1)
		{
			av_free_packet(&pkt);
			continue;
		}
        in_stream  = ifmt_ctx->streams[pkt.stream_index];
        out_stream = ofmt_ctx->streams[map_table[pkt.stream_index].output_index];

        // skip non-key video frame 
        if (!init_keyframe){
            if ((map_table[pkt.stream_index].type == AVMEDIA_TYPE_VIDEO) && (pkt.flags & AV_PKT_FLAG_KEY)){
                init_keyframe = 1;
				offset=-pkt.pts;
            }
            else{
                av_free_packet(&pkt);
                continue;
            }
        }

			
        // copy packet 
       	if (map_table[pkt.stream_index].type == AVMEDIA_TYPE_VIDEO)
		{
			pkt.pts += offset;
			pkt.dts += offset;
			if (pkt.dts>pkt.pts+1/av_q2d(in_stream->time_base))
			{
				pkt.dts=pkt.pts;
			}
			videopts = pkt.pts;
			pkt.pts = av_rescale_q_rnd(pkt.pts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.dts = av_rescale_q_rnd(pkt.dts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.duration = av_rescale_q(pkt.duration, in_stream->time_base, out_stream->time_base);	

			*ts2mp4_transform_pec=(pkt.dts*100) / videototaldur;
		}else
		{
			pkt.pts=audiopts;
			pkt.dts=audiopts;
			int oridur=pkt.duration;
			pkt.pts = av_rescale_q_rnd(pkt.pts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.dts = av_rescale_q_rnd(pkt.dts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.duration = av_rescale_q(pkt.duration, in_stream->time_base, out_stream->time_base);	

			int k0=(audiopts*1000*av_q2d(atimebase)-videopts*1000*av_q2d(vtimebase));
			if((audiopts>0)&&(k0>100))
			{
				continue;
			}

			audiopts+=oridur;
		}
		pkt.pos = -1;
				
        out_pkt = pkt;
        out_pkt.stream_index = map_table[pkt.stream_index].output_index;

        // process AAC packet 
        if (in_stream->codec->codec_id == AV_CODEC_ID_AAC){
			av_bitstream_filter_filter(bsfc, out_stream->codec, NULL, &out_pkt.data, &out_pkt.size, pkt.data, pkt.size, pkt.flags & AV_PKT_FLAG_KEY);
        }
        ret = av_interleaved_write_frame(ofmt_ctx, &out_pkt);
        if (ret < 0) {
            plog(1, "ts2mp4_transform: Error muxing packet.\r\n");
            ret = -10;
            break;
        }

        //av_free_packet(&pkt);
    }

    av_write_trailer(ofmt_ctx);
	*ts2mp4_transform_pec=100;

end:

    avformat_close_input(&ifmt_ctx);

    /* close output */
    if (ofmt_ctx && !(ofmt->flags & AVFMT_NOFILE))
        avio_close(ofmt_ctx->pb);
    avformat_free_context(ofmt_ctx);

    if (bsfc)
	    av_bitstream_filter_close(bsfc);

    if (ret < 0 && ret != AVERROR_EOF) {
        plog(1, "ts2mp4_transform: Error occurred: %d.\r\n", ret);
        return 1;
    }

    return 0;
}


