#include <sys/prctl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/un.h>

#include "initialize.h"
#include "TS.h"

int fd_pipe;
unsigned char *monitor=NULL;
int alltime=0;

extern int msgid;
fun_names plugin()
{
	fun_names a=get_argv(3, "TS_MAIN", "TS_WRITE", "TS2MP4");
	return a;
}

void TS_pipe_init(void)
{
	mkfifo("tmp_TS.pipe",0666);
	fd_pipe=open("tmp_TS.pipe",O_RDWR);
}

int stream_pipe_init(void)
{
	int pipe;
	mkfifo("tmp_socket_0.pipe",0666);
	pipe=open("tmp_socket_0.pipe",O_RDWR);
	shutdown(pipe,SHUT_RD);
	return pipe;
}

void state_init(void)
{
	int fd;
	fd=open("tmp_dat",O_RDWR|O_CREAT|O_EXCL,0666);
	if(fd==-1)
	{
		fd=open("tmp_dat",O_RDWR);
	}
	ftruncate(fd, 256);
	monitor = mmap(0, 256, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
	monitor[0]='D';
	close(fd);
}

void sig_alrm(int signo)
{
	alltime++;
	if( alltime>5 ) alltime=0;
}

int cmd_parse(unsigned char cmd, unsigned char num)
{
	if(monitor[num]==0    && cmd==1)
	{
		monitor[num] = 0xff;
		return 1;
	}
	if(monitor[num]==0xff && cmd==1) return 0;
	if(monitor[num]>0     && cmd==1)
	{
		plog(4, "Rec retry for class %d, IGNORE the error code %d!\r\n", num, monitor[num]);
		monitor[num] = 0xff;
		return 1;
	}
	if(monitor[num]==0    && cmd==0) return 0;
	if(monitor[num]==0xff     && cmd==0)
	{
		monitor[num] = 0;
		plog(0, "Class %d's REC closing!\r\n", num);
		return 0;
	}
	if(monitor[num]>0     && cmd==0)
	{
		plog(5, "Erase the error code %d for class %d!\r\n", monitor[num], num);
		monitor[num] = 0;
		return 0;
	}
	plog(4, "Function cmd_parse execute ERR! cmd=%d,num=%d,monitor[%d]=%d\r\n", cmd, num, num, monitor[num]);
	return 0;
}

int process(cmd_pakg *cp, unsigned char cmd_buf[])
{
	cp->cmd_chan = cmd_buf[1];
	cp->ip_addr = cmd_buf[2]	 | cmd_buf[3]<<8  |
				  cmd_buf[4]<<16 | cmd_buf[5]<<24;
	if(cp->ip_addr==0 || cp->ip_addr==-1)
	{
		plog(4, "REC commmand ERR, commmand's IP is 0.0.0.0 or 255.255.255.255\r\n");
		return 1;
	}
	bzero(cp->file, sizeof(cp->file));
	strncpy(cp->file, cmd_buf+6, 14);
	if(strlen(cp->file)!=14)
	{
		plog(4, "REC commmand ERR, command's REC-name:%s, length=%d\r\n", cp->file, (int)strlen(cp->file));
		return 1;
	}
	sprintf(cp->file+14, "%02X%s", cmd_buf[1], ".TS");
	return 0;
}

void* tswrite(void *cp)
{
	cmd_pakg *pakg=(cmd_pakg *)cp;
	int serve_fd;
	int file_fd;
	int r;
	unsigned char file_buf[BUF_SIZE_T];
	unsigned char file_name[20];
	unsigned char cmd_chan;
	struct timeval timeout;
	struct msgbf msg;
	unsigned char address[50];
	int ptime=alltime-1;
	char name[255];
	int pipe=stream_pipe_init();
	
	stream_cmd_pakg pkg;
	pkg.chan =pakg->cmd_chan;						//命令号
	pkg.cmd=1;						//时间
	pkg.ip_addr=pakg->ip_addr;						//ip地址
	pkg.port=5223;
	strncpy(file_name, pakg->file, 20);
	cmd_chan = pakg->cmd_chan;
	free(pakg);

	pthread_detach(pthread_self());
	plog(0, "Class %d. Pthread_create success.\r\n", pkg.chan);
	int restart = 0;
//Start socket
loop:
	r=write(pipe,&pkg,sizeof(stream_cmd_pakg));
	if(r<1)plog(4, "Class %d. Connect STREAM ERR: Send %d bytes.\r\n", pkg.chan, r);
	else plog(0, "Class %d. Connect STREAM by sending stream's pipe %d bytes.\r\n", pkg.chan, r);
	usleep(100000);
    struct sockaddr_un addr={0};

    serve_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    addr.sun_family = AF_UNIX;
	sprintf(name, "./tmp_socket_%d.%d.%d.%d", pkg.ip_addr%256,(pkg.ip_addr>>8)%256, (pkg.ip_addr>>16)%256, pkg.ip_addr>>24);

    snprintf(addr.sun_path, UNIX_PATH_MAX, "%s", name);
    r=connect(serve_fd,(struct sockaddr *) &addr,sizeof(struct sockaddr_un));
	if ( r==-1 )
	{
		close(serve_fd);
		plog(4, "Class %d. Connect err:%s\r\n", pkg.chan, strerror(errno) );
		usleep(500000);
		restart++;
		if(restart>3){close(pipe);pthread_exit(0);}
		goto loop;
	}
	else close(pipe);
//Creat file
	get_path("[TS-ADDRESS]", "/var/tstmp/", address, NULL);

	CreateDirectoryEx(address);
	
	strcpy(address+strlen(address), file_name);
	file_fd = open(address, O_RDWR|O_CREAT|O_TRUNC, 00666 );
	if ( file_fd==-1 )
	{
		close ( serve_fd );
		close ( file_fd );
		plog(4, "Class %d. TS-file creat err:%s\r\n", pkg.chan, strerror(errno) );
		monitor[cmd_chan] = FILE_CREAT_ERR;
		return;
	}
	else
	{
		plog(3, "Class %d is RECing...\t\t%s\r\n", pkg.chan, address);
	}
	
//Receive packeges	
	int test=0;
	timeout.tv_sec = 1; 
	timeout.tv_usec = 0;
	setsockopt(serve_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(struct timeval));
	while(1)
	{
		if( monitor[cmd_chan]==0 ){ plog(3, "Class %d's REC closed!\r\n", cmd_chan); break; }
		r = recv(serve_fd, file_buf, sizeof(file_buf), MSG_WAITALL);
		if( r<1 )
		{
				plog(4, "Class %d. Socket break form STREAM! MSG:%s. AUTO Repaired.(CLOSE:%d)\r\n", pkg.chan, strerror(errno), 10-restart);
				if(restart++ > 9){ monitor[pkg.chan]=NETWORK_ERR; break; }
				else continue;
		}
		test=write( file_fd , file_buf , r );
		if(test==-1)
		{
			plog(4, "Class %d. TS-file write err:%s(The disk is FULL?)\r\n", pkg.chan, strerror(errno));
			monitor[cmd_chan] = WRITE_ERR;
			break;
		}
		else restart = 0;
		if(ptime==alltime)
		{
			plog(4, "Class %d. TS REC had reach the limit of REC time!!!(6 hours)\r\n", pkg.chan);
			monitor[cmd_chan] = TIME_UP;
			break;
		}
	}

//Finish
	bzero(msg.data,sizeof(msg.data));
	msg.type=777;
	sprintf(msg.data, "%s", address);
	r=msgsnd(msgid, &msg, sizeof(msg.data), 0);
	if(r==-1)plog(4, "Class %d. TS-file(%s) send error=%s\r\n", pkg.chan, msg.data, strerror(errno));
	else plog(3, "Class %d. TS-file(%s) sended to tramsform.\r\n", pkg.chan, msg.data);
	close ( file_fd );
	close ( serve_fd );
	plog(0, "Class %d REC finished!\r\n", cmd_chan);
	pthread_exit(0);
//	return( Succeed );
}



void TS_WRITE()
{
	char ads[50];
	int r=0;
	int id=5;
	prctl(PR_SET_NAME, "TS-WRITE", NULL, NULL, NULL);
	get_path("[TS-LOG]", "/var/log/drs8/TS", ads, &id);
	if( init_LOG(msgid, id, ads, "[TS-WRITE]") )
		plog(4, "init LOG error. This is [TSWRITE]!!!\r\n");
	
	if( r=free_space(ads) ){
			plog(4, "Disk is FULL(%dMB available)!!!\r\n", r-1);
			plog(3, "REC service CLOSED!!!\r\n");
			sleep(3600);
			return;
	}
	
	cmd_pakg *cp = NULL;
	unsigned char cmd_buf[SIGNAL_PAKG_SIZE];
	pthread_t ts;
	int res=1;
	struct itimerval val={0};
	
	val.it_value.tv_sec=1;
	val.it_interval.tv_sec=3600;
	setitimer(ITIMER_REAL, &val, 0);
	signal(SIGALRM, sig_alrm);
	
	state_init();
	TS_pipe_init();
	while( msg_init(&msgid, 200)>0)
	{
		plog(4, "Msg for connecting with TS-TS2MP4 err!\r\n");
		sleep(10);
	}
	
	plog(0, "Program Start!!!\r\n");
	
	while(1)
	{
		cp = (cmd_pakg *)malloc( sizeof(cmd_pakg) );
		if( cp==NULL )
		{
			plog(4, "Can't recv REC commmand. Malloc failed:NO others space!%s\r\n", strerror(errno));
			sleep(2);
			continue;
		}
		r= read(fd_pipe,cmd_buf,sizeof(cmd_buf));
		plog(0, "Receive REC commmand by pipe success!recv %d bytes\r\n", r);
		
		if( cmd_buf[1]==0 )
		{
			plog(4, "REC commmand ERR, there is no class 0!!!\r\n");
			continue;
		}
		//*********************************************
		if( process(cp, cmd_buf) )continue;
		if( cmd_parse(cmd_buf[0], cmd_buf[1]) )
		{
			plog(0, "Prepare for class %d's REC.\r\n", cmd_buf[1]);
			res = pthread_create(&ts, NULL, &tswrite, cp);
			usleep(1);
			if (res != 0)
			{
				plog(4, "Class %d's REC error, pthread can't create:%s\r\n", cmd_buf[1], strerror(errno));
				monitor[cmd_buf[1]] = CORE_BREAK;
				free(cp);
			}
		}
		else
		{
			if(cmd_buf[0]==1) plog(4, "Function cmd_parse return 0\tmonitor[%d]=%d\r\n",cmd_buf[1],monitor[cmd_buf[1]]);
			free(cp);			
		}
	}
	free( cp );
	cp = NULL;
	munmap(monitor, 256);
}

void* main_thread(void* cp)
{
	struct timeval timeout;
	int offset = 0;
	unsigned char cmd_buf[1423];
	unsigned char *pcmd_buf;
	int pakg_num;
	int i, r;
	
	int client_fd=*(int*)cp;
	free(cp);
	pthread_detach(pthread_self());
	timeout.tv_sec = 10; 
	timeout.tv_usec = 0;
	setsockopt(client_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(struct timeval));
	setsockopt(client_fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(struct timeval));
	while(1)
	{
	//recv command packege
		bzero(cmd_buf, sizeof(cmd_buf));
		
		r = recv(client_fd, cmd_buf ,sizeof(cmd_buf)-20, 0);
		if ( r==-1 || r==0 || cmd_buf[0]!=WEB_TO_DRS_HEAD )
		{
			if( r==-1 || r==0 )
			{
				if(errno==EINTR) continue;
				plog(3, "JT-WEBS(fd:%d) break the socket automatically. Break code:%d(%s)\r\n", client_fd, r, r==-1?strerror(errno):"NULL");
				break;
			}
			else 
			{
				plog(4, "JT-WEBS(fd:%d) send error cmd:\tHEAD=%c(%d)\tr=%d\t\r\n", client_fd, cmd_buf[0], cmd_buf[0], r);
				continue;
			}
		}
		else
		{
			pcmd_buf=cmd_buf;
			offset = 0;
			while(1)
			{
				pakg_num = pcmd_buf[1];
				if(pakg_num!=0)
				{
					plog(0, "Command parse:head [%c]\tcounts %d\r\n", pcmd_buf[0] ,pakg_num );
				}
				if(offset+pakg_num*20+2>sizeof(cmd_buf))break;
				for(i=0; i<pakg_num; i++)
				{
					plog(0, "Command %d:Class %u %s the REC. The coder's IP=%u.%u.%u.%u\r\n", i+1,
						   pcmd_buf[3+20*i], pcmd_buf[2+20*i]==1?"START":"CLOSE", pcmd_buf[4+20*i], pcmd_buf[5+20*i], pcmd_buf[6+20*i], pcmd_buf[7+20*i]);
					r=write(fd_pipe,pcmd_buf+2+20*i,20);
					if(r==20) plog(0, "Send the command successfully by pipe(20 bytes).\r\n");
					else plog(4, "Send the command failed! Writed %d bytes\r\n", r);
					
				}
				if((offset+pakg_num*20+2<sizeof(cmd_buf)-20) && (pcmd_buf[pakg_num*20+2]=='W'))
				{
					pcmd_buf=pcmd_buf+pakg_num*20+2;
					offset+=pakg_num*20+2;
				}
				else
					break;
			}
		}
		//send back message
		r=send(client_fd, monitor, 256, 0);
		if(r<1)plog(4, "Socket send feedback  failed! Err code %d. %s\r\n", r, strerror(errno));
	}
//finish
	close ( client_fd );
}

void TS_MAIN()
{
	char ads[50];
	int r=0;
	int id=5;
	prctl(PR_SET_NAME, "TS-MAIN", NULL, NULL, NULL);
	get_path("[TS-LOG]", "/var/log/drs8/TS", ads, &id);
	if( init_LOG(msgid, id, ads, "[TSMAIN]") )
		plog(4, "init LOG error. This is [TSMAIN]!!!\r\n");
	plog(6, "\r\n------------------------TS new start------------------------\r\n" );
	
	if( r=free_space(ads) ){
			plog(4, "Disk is FULL(%dMB available)!!!\r\n", r-1);
			plog(3, "REC service CLOSED!!!\r\n");
			sleep(3600);
			return;
	}
	
	signal(SIGPIPE, SIG_IGN);
	state_init();
	TS_pipe_init();
	int server_fd, *client_fd;
	int opt = SO_REUSEADDR;
	pthread_t ts_main;

	struct sockaddr_in server_addr = {0};
	struct sockaddr_in client_addr = {0};
	socklen_t len;
	
//start socket
	server_fd=socket( AF_INET,SOCK_STREAM ,6 );
	if ( server_fd==-1 )
	{
		close ( server_fd );
		plog(4, "socket err:%s\r\n", strerror(errno));
		return;
	}
	
	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
//bind&listen
	server_addr.sin_family = AF_INET;
	server_addr.sin_port   = htons( SERVER_PROT );
	server_addr.sin_addr.s_addr=htonl(INADDR_ANY); 
	r = bind(server_fd, (struct sockaddr*) &server_addr, sizeof(server_addr));
	if( r==-1 )
	{
		close ( server_fd );
		plog(4, "bind err:%s\r\n", strerror(errno)); 
		return;
	}

	r = listen( server_fd , 10 );
	if( r==-1 )
	{
		close ( server_fd);
		plog(4, "listen err:%s\r\n",  strerror(errno));
		return;
	}
	else
	{
		plog(0, "Port:%d\tListenning!\r\n", SERVER_PROT);
	}
//accept client
while(1)
{
	len = sizeof( client_addr );
	client_fd = (int *)malloc( sizeof(int) );
	*client_fd = accept( server_fd, (struct sockaddr*) &client_addr, &len );
	if( *client_fd==-1 )
	{
		plog(4, "accept err:%s\r\n", strerror(errno));
		free(client_fd);
		sleep(3);
		continue;//break;
	}
	else
	{
		plog(3, "JT-WEBS connected:%d,ip:%s:%u\r\n" ,
			*client_fd,								//num
			inet_ntoa( client_addr.sin_addr ),		//show ip
			ntohs(client_addr.sin_port) );			//show port number

		r = pthread_create(&ts_main, NULL, &main_thread, client_fd);
		if (r != 0)
		{
			plog(4, "JT-WEBS pthread create error, pthread can't create:%s\r\n", strerror(errno));
			close ( *client_fd );
			free(client_fd);
			sleep(3);
		}
	}
}
	close ( server_fd );
	plog(4, "drsmain core break !\r\n" );
	return;
}

void TS2MP4()
{	
	char log[5];
	sprintf(log, "%d", msgid);
	execl("./plugin/TS-TS2MP4","TS-TS2MP4", log, NULL);
}
