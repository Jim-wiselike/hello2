#ifndef _STREAM_H_
#define _STREAM_H_

typedef struct cmd_pakg{
	unsigned char chan;						//命令号
	unsigned char cmd;						//时间
	unsigned int ip_addr;						//ip地址
	unsigned int port;
}cmd_pakg;

typedef struct ip_qu{
	unsigned int ip_addr;
	unsigned int port;
	unsigned char chan;	
	struct ip_qu* next;
}ip_qu;

typedef struct con_qu{
	int fd;
	struct con_qu* next;
}con_qu;

#define BUFF_SIZE (188*10)
#define CODER_ERROE		200

#endif
