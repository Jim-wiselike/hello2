#include<dirent.h>
#include<dlfcn.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

#include "initialize.h"

plugin_vel* pls=0;
int msgid;
int num=0;

void clean_plugin()
{
	int i=0;
	for(i=3; i<15; i++)
		close(i);
}

int re_exec(int k)
{
	void *handle = dlopen(pls[k].path, RTLD_LAZY);	//打开动态库
	if(handle == 0){
		char* str=dlerror();
		plog(4, "%s\r\n",str);
		return 0;
    }

	get_fun f2 = (get_fun)dlsym(handle, pls[k].funname);		//找到函数
	if(f2 == NULL)
	{
		char* str=dlerror();
		plog(4, "%s\r\n", str);
		dlclose(handle);
		return 0;
	}
	else
	{
		if( (pls[k].pid=fork())==0 )
		{
			free(pls);
			clean_plugin();
			sleep(1);
			(*f2)();
			exit(-1);
		}
		plog(0, "dlfun RE-EXEC sucessfully!file%s %s (PID=%d)\r\n", pls[k].path, pls[k].funname, pls[k].pid);
	}
	dlclose(handle);
	return 1;
}

void sig_chld(int signo) 
{ 
	pid_t pid; 
	int i=0;
	int flag=1;
	static long long restart=0;
	static struct timeval tv_bf;
	struct timeval tv;
	signal(SIGCHLD, sig_chld);
	gettimeofday(&tv, NULL);
	while((pid = waitpid(-1, NULL, WNOHANG | WUNTRACED)) > 0)
	{
		for(i=0; i<num; i++)
		{
			if(pid==pls[i].pid)
			{
				plog(4, "The program %s (PID=%d) RESTARTED!\r\n", pls[i].funname, pid);
				flag=0;
				pls[i].restart=1;
				break;
			}
		}
		if(flag)plog(4, "child NO NAME terminated(PID=%d)!\r\n", pid);
	}
	if(tv.tv_sec - tv_bf.tv_sec <= 300) restart++;
	tv_bf=tv;
	if( restart>=100 )
	{
		struct tm tm;
		localtime_r(&tv.tv_sec, &tm);
		if( (tm.tm_hour-12)>=9 || (tm.tm_hour<=6) )
		{
			plog(4, "MAIN program RESTART flag(%d%%) reached 100%%! System reboot!!!\r\n", restart);
			system("reboot");
		}
	}
	puts("MAIN program FATAL failure!!");
	return; 
}

void add_exec(void *handle,fun_names names,const char* FileName)
{
	int i;
	for(i=0; i<names.num; i++)
	{
		get_fun f1 = (get_fun)dlsym(handle, names.fun[i]);		//找到函数
		if(f1 == 0)
		{
			char* str=dlerror();
			plog(4, "Can't find dlfun %s:%s\r\n", names.fun[i], str);
		}
		else
		{
			if( (pls[num].pid=fork())==0 )
			{
				clean_plugin();
				free(pls);
				 (*f1)();
				exit(-1);
			}
			plog(0, "dlfun exec sucessfully:%s (PID=%d)\r\n", names.fun[i], pls[num].pid);
			sprintf(pls[num].path, "%s", FileName);
			sprintf(pls[num].funname, "%s", names.fun[i]);
			pls[num].restart=0;
			num++;
		}
	}
}

int libname(const char *FileName)
{
	int i;
	for(i=0; i<num; i++)
	{
		if( !strcmp(pls[i].path, FileName) )
			return 1;
	}
	return 0;
}

int libopen(const char *FileName)
{
	if( libname(FileName) ) return 0;
    void *handle = dlopen(FileName, RTLD_LAZY);	//打开动态库
    if(handle == 0)
    {
		return 1;
    }

    get_fun f1 = (get_fun)dlsym(handle, "plugin");		//找到fun函数
    if(f1 == 0)
    {
		dlclose(handle);
		char* str=dlerror();
		plog(4, "plugin function exec err:%s\r\n", str);
		return 1;
    }
	fun_names names=(*f1)();	//执行函数
	add_exec(handle, names, FileName);
	free(names.fun);
    dlclose(handle);			//关闭动态库
    return 0;
}

int chklib(const char* path)
{
	int i;
	for(i=0; i<num; i++)
	{
		if( !strcmp( path, pls[num].path) )
			return 0;
	}
	return 1;
}

void file(const char* File)
{
    DIR *dir;
    struct dirent *ptr;
    dir=opendir( File );		//打开指定文件夹
    char file[255];
    while( (ptr=readdir(dir))!=NULL )		//循环遍历所有文件
    {
		int l=strlen( ptr->d_name );
		if( l<4 ) continue;				//跳过非动态库文件
		sprintf(file, "%s/%s", File, ptr->d_name);
		if( chklib(File) )
			libopen(file);					//执行动态库中的函数
    }
    closedir(dir);
}

void main(int argc, char** argv)
{
	char ads[50];
	msgid=atoi(argv[1]);
	int id=2;
	printf("MAIN:\targc=%d, argv[1]=%d\r\n", argc, msgid);
	get_path("[MAIN-LOG]", "/var/log/drs8/MAIN", ads, &id);
	init_LOG(msgid, id, ads, "[MAIN]");
	plog(6, "\r\n---------------MAIN new start----------------------\r\n");
	signal(SIGCHLD, sig_chld);
	pls= (plugin_vel*)malloc(sizeof(plugin_vel)*300);
	int i;
	while(1)
	{
		if( access("./plugin", F_OK)!=0 )
			mkdir("./plugin",0755);
		file("./plugin");	//打开当前目录，并执行其中的插件
		sleep(10);
		
		for(i=0; i<num; i++)
		{
			if(1==pls[i].restart)
			{
				pls[i].restart=0;
				if(re_exec(i)!=1){
					plog(4, "RESTARTED %s(PID=%s) Failed!!!\r\n", pls[i].funname, pls[i].pid);
					pls[i].pid = 0;
				}
			}
		}
	}
}
