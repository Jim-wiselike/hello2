#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <signal.h>
#include <unistd.h>
#include <sys/epoll.h>

#include "initialize.h"
#include "rtmp_main.h"

unsigned char *monitor=NULL;
List classes={0};
char log_exec[5]={0};

extern int msgid;

class* find(pid_t pid)
{
	class* result=classes.head;
	while( result!=NULL )
	{
		if(result->pid==pid) return result;
		else result = result->next;
	}
	return NULL;
}

void sig_chld_rtmp(int signo) 
{
	pid_t pid; 
	int status=0;
	class* result=NULL;
	while((pid = waitpid(-1, &status, WNOHANG | WUNTRACED)) > 0)
	{
		result = find(pid);
		if(result==NULL) plog(3, "Unknow class closed! \tPID=%d,status=%d.\r\n", pid, WEXITSTATUS(status));
		else
		{
			if(monitor[result->room]&&!(monitor[result->room]>200&&monitor[result->room]<254)){
				monitor[result->room] = WEXITSTATUS(status)==0?254:WEXITSTATUS(status);
				if((result->pid=fork())==0){
					char ip_coder[20];
					char room[4];
					sprintf(ip_coder, "%d", result->ip_addr);
					sprintf(room, "%d", result->room);
					plog(3, "RTMP restarting for class%d by sig status=%d...\r\n", result->room, monitor[result->room]);
					execl("./plugin/RTMP-EXEC","RTMP-EXEC", log_exec, ip_coder, room, result->rtmp_path, NULL);
				}
			}
			else
				plog(0, "Class %d's RTMP-living is closed.\r\n", result->room);
		}
	}
	return; 
}

void state_init(void)
{
	int fd;
	fd=open("tmp_rtmp",O_RDWR|O_CREAT|O_EXCL,0666);
	if(fd==-1)
	{
		fd=open("tmp_rtmp",O_RDWR);
	}
	ftruncate(fd, 256);
	monitor = mmap(0, 256, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
	close(fd);
}

fun_names plugin()
{
	fun_names a=get_argv(2, "RTMP_MAIN", "RTMP_EXEC");
	return a;
}

int con_server()
{
	char name[UNIX_PATH_MAX+1];
	int r;
    struct sockaddr_un addr={0};

    int serve_fd = socket(AF_UNIX, SOCK_STREAM, 0);
 
    addr.sun_family = AF_UNIX;
	sprintf(name, "tmp_rtmp_server");

    snprintf(addr.sun_path, UNIX_PATH_MAX, "%s", name);
    r=connect(serve_fd,(struct sockaddr *) &addr,sizeof(struct sockaddr_un));
	if ( r==-1 )
	{
		close(serve_fd);
		plog(4, "connect err!\r\n");
		return -1;
	}
	return serve_fd;
}

void* main_thread(void* cp)
{
	struct timeval timeout;
	int offset = 0;
	unsigned char cmd_buf[1501];
	unsigned char send_buf[1000];
	unsigned char send_tmp[14]={0};
	int pakg_num, r;
	
	int ser_fd=0, client_fd=*(int*)cp;
	free(cp);
	pthread_detach(pthread_self());
	timeout.tv_sec = 10; 
	timeout.tv_usec = 0;
	setsockopt(client_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(struct timeval));
	setsockopt(client_fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(struct timeval));
	while(1)
	{
	//recv command packege
		bzero(cmd_buf, sizeof(cmd_buf));
		if(client_fd>0) r=recv(client_fd, cmd_buf ,1500 , 0);
		else r=-1;
		if ( r==-1 || r==0 || cmd_buf[0]!=WEB_TO_DRS_HEAD )
		{
			if( r==-1 || r==0 )
			{
				if(errno==EINTR) continue;
				plog(3, "JT-WEBS(fd:%d) break the socket automatically. Break code:%d(%s)\r\n", client_fd, r, r==-1?strerror(errno):"NULL");
				break;
			}
			else 
			{
				plog(4, "JT-WEBS send error cmd:\tHEAD=%c(%d)\tr=%d\t\r\n", cmd_buf[0], cmd_buf[0], r);
				continue;
			}
		}
		else
		{
			if( r<3 || (r-2!=cmd_buf[1]) )
			{
				if(r!=2)plog(4, "Chkd %d bytes of packet !!! The Packet is not complete!\r\n", r);
				if(monitor[0]!='T')monitor[0]='T';
				send(client_fd, monitor, 256, 0);
				continue;
			}
			
			if( ser_fd==0 )
			if( (ser_fd = con_server()) == -1)
				break;;
			if((r=send(ser_fd, cmd_buf+2, cmd_buf[1]+1, 0))<0)
			{
				plog(4, "Socket send to rtmp_server failed! Err code %d. %s\r\n", r, strerror(errno));
				goto LOOP;
			}
			plog(0, "chkdate %d data finished, send cmd to execute!\r\n", cmd_buf[1]);
			if(monitor[0]!='T')monitor[0]='T';
			r = send(client_fd, monitor, 256, 0);
			if(r<1)plog(4, "Socket send feedback failed! Err code %d. %s\r\n", r, strerror(errno));
		}
	}
LOOP://finish
	close ( client_fd );
	if( ser_fd!=0 )close ( ser_fd );
}

void rtmpmain()
{
	int server_fd, *client_fd;
	int r ;

	struct sockaddr_in server_addr = {0};
	struct sockaddr_in client_addr = {0};
	socklen_t len;
	int opt = SO_REUSEADDR;
	pthread_t rt_main;

	plog(6, "\r\n------------------------RTMP new start------------------------\r\n" );
//start socket
	server_fd=socket( AF_INET,SOCK_STREAM ,6 );
	if ( server_fd==-1 )
	{
		close( server_fd );
		plog (1, "socket err:%s\r\n", strerror(errno));
		return;
	}
	
	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
//bind&listen
	server_addr.sin_family = AF_INET;
	server_addr.sin_port   = htons( SERVER_PROT );
	server_addr.sin_addr.s_addr=htonl(INADDR_ANY); 
	r = bind(server_fd, (struct sockaddr*) &server_addr, sizeof(server_addr));
	if( r==-1 )
	{
		close( server_fd );
		plog (1, "bind err:%s\r\n", strerror(errno));
		return;
	}

	r = listen( server_fd , 10 );
	if( r==-1 )
	{
		close( server_fd);
		plog (1, "listen err:%s\r\n", strerror(errno));
		return;
	}
	else plog(0,"Port:%d\tListenning!\r\n", SERVER_PROT);
	
//accept client
while(1)
{
	len = sizeof( client_addr );
	client_fd = (int *)malloc( sizeof(int) );
	*client_fd = accept( server_fd, (struct sockaddr*) &client_addr, &len );
	if( *client_fd==-1 )
	{
		plog(4, "accept err:%s\r\n", strerror(errno));
		free(client_fd);
		sleep(3);
		continue;//break;
	}
	else
	{
		plog(3, "JT-WEBS connected:%d,ip:%s:%u\r\n" ,
				*client_fd,								//num
				inet_ntoa( client_addr.sin_addr ),		//show ip
				ntohs(client_addr.sin_port) );			//show port number
		r = pthread_create(&rt_main, NULL, &main_thread, client_fd);
		if (r != 0)
		{
			plog(4, "JT-WEBS pthread create error, pthread can't create:%s\r\n", strerror(errno));
			close ( *client_fd );
			free(client_fd);
			sleep(3);
		}
	}
}
	close( server_fd );
	plog (1, "rtmpmain core break!!!\r\n" );
	return;
}

int start_socket()
{
	struct sockaddr_un server_addr={0};
    int socket_fd;
	char name[255];

	sprintf(name, "tmp_rtmp_server");
	unlink(name);
//	name[0]=0;//不产生socket临时文件
    socket_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    server_addr.sun_family = AF_UNIX;
	snprintf(server_addr.sun_path, UNIX_PATH_MAX, "%s", name);

    if(bind(socket_fd,(struct sockaddr *) &server_addr,sizeof(server_addr)) != 0)
	{
        plog(4, "bind(%s) failed:%s\r\n", name, strerror(errno));
        return -1;
    }

    if(listen(socket_fd, 5) != 0)
    {
        plog(4, "listen(%s) failed%s\r\n", name, strerror(errno));
        return -1;
    }
	return socket_fd;
}

int compare(class* result, class* cmd)
{
	if(result->room!=cmd->room)
		return 0;
	return 1;
}

int process(class* result, class* cmd)
{
	if(result == NULL)return 0;
	if(compare(result, cmd)) return 0;
	return 1;
}

void add_class(class* cmd)
{
	if(classes.head==NULL || classes.end==NULL)
	{
		classes.head = cmd;
		classes.end = cmd;
	}
	else
	{
		classes.end->next = cmd;
		classes.end = cmd;
	}
}

class* parse(unsigned char *cmd_buf)
{
	class* cmd = (class*)malloc(sizeof(class));
	class* result=classes.head;
	
	cmd->pid=0;
	cmd->room = cmd_buf[1];
	cmd->ip_addr =  cmd_buf[2]	 | cmd_buf[3]<<8  |
				  cmd_buf[4]<<16 | cmd_buf[5]<<24;
	snprintf(cmd->rtmp_path,strlen(cmd_buf+6)+1 , "%s", cmd_buf+6);
	cmd->next = NULL;

	plog(0, "RTMP-command parse:\r\n");
	plog(0, "RTMP-LIVE %s to play %s for class %d, The coder's IP=%u.%u.%u.%u\r\n", cmd_buf[0]==1?"START":cmd_buf[0]==0?"CLOSE":cmd_buf[0], cmd->rtmp_path, cmd->room,
	cmd_buf[2], cmd_buf[3], cmd_buf[4], cmd_buf[5]);

	if(classes.head==NULL || classes.end==NULL)
	{
		result = cmd;
		add_class(cmd);
		result->ans = 0;
	}
	else
	{
		while(process(result, cmd))
		{
			result = result->next;
		}
		if(result == NULL)
		{
			add_class(cmd);
			result = cmd;
			result->ans = 0;
		}
		else
		{
			if(result->ip_addr!=cmd->ip_addr){
				result->ip_addr=cmd->ip_addr;
				if(cmd_buf[0]) result->ans = 3;
			}
			
			if(strcmp(result->rtmp_path, cmd->rtmp_path)){
				sprintf(result->rtmp_path, "%s", cmd->rtmp_path);
				if(cmd_buf[0]) result->ans = 3;
			}
			free(cmd);
		}
	}
	switch(cmd_buf[0])
	{
		case 1: if(monitor[result->room]==0){
					monitor[result->room]=254; result->ans=1;  
				}
				else if(result->ans != 3){
					plog(4, "JT-WEBS send duplicate command.\tmonitor[%d]=%d(Raw data) cmd:START ans=%d\r\n", result->room, monitor[result->room],result->ans);
					if(monitor[result->room]>200&&monitor[result->room]<254) result->ans=1;
					}
					else
					plog(4, "JT-WEBS send new command.\tmonitor[%d]=%d(Raw data) RTMP-LIVE restart!!!\r\n", result->room, monitor[result->room]);
				break;
		case 0: if(monitor[result->room]!=0){
				monitor[result->room]=0; result->ans=2;
				}
				else{
				plog(4, "Class %d is already closed!!!\r\n", result->room); result->ans = 0;
				}
				break;
		default: result->ans = 0; break;
	}
	return result;
}

int handle_message(int fd)
{
	char cmd_buf[1500]={0};
	class * result;
	if( recv(fd, cmd_buf ,1500, 0) <1 )
	{
		plog(4, "Class(fd:%d) break the socket! Break code:%s\r\n", fd, strerror(errno));
		return -1;
	}
	if( !cmd_buf[1] )
	{
		plog(4, "Commmand ERR, there is no class 0!!!\r\n");
		return 0;
	}
	result = parse(cmd_buf);
	switch(result->ans)
	{
		case 1:
			monitor[result->room]=254;
			if((result->pid=fork())==0)
			{//logid, ip coder, num, ip ser, classname, method
				plog(3, "RTMP starting...\r\n");
				char ip_coder[20];
				char room[4];
				sprintf(ip_coder, "%d", result->ip_addr);
				sprintf(room, "%d", result->room);
				execl("./plugin/RTMP-EXEC","RTMP-EXEC", log_exec, ip_coder, room, result->rtmp_path, NULL);
			}
			else result->ans=0;
			break;
		case 2:
			plog(3, "RTMP closed...\r\n");
// 			kill(result->pid, 9);
			result->ans=0;
			break;
		case 3:
			plog(3, "RTMP killed...\r\n");
			kill(result->pid, 9);
			monitor[result->room]=254;
			plog(3, "RTMP restarting...\r\n");
			if((result->pid=fork())==0)
			{//logid, ip coder, num, ip ser, classname, method
				char ip_coder[20];
				char room[4];
				sprintf(ip_coder, "%d", result->ip_addr);
				sprintf(room, "%d", result->room);
				execl("./plugin/RTMP-EXEC","RTMP-EXEC", log_exec, ip_coder, room, result->rtmp_path, NULL);
			}
			else result->ans=0;
		default:
			break;
	}
	if(monitor[0]!='T')monitor[0]='T';
	send(fd, monitor, 256, 0);
	return 0;
}

void rtmpsever()
{	
	struct epoll_event ev;  
    struct epoll_event events[MAXEPOLLSIZE]; 
	int curfds=0, nfds, n, new_fd;
	int skt_ser = start_socket();
	if(skt_ser==-1)
	{
		return ;
	}
	int pollfd = epoll_create(MAXEPOLLSIZE);
	ev.events = EPOLLIN;
	ev.data.fd = skt_ser;
	if (epoll_ctl(pollfd, EPOLL_CTL_ADD, skt_ser, &ev) < 0)
	{
		plog(4, "epoll set insertion error: fd=%d .Err:%s\r\n", skt_ser, strerror(errno));
		return;
	}
	curfds=1;
	while(1)
	{
		nfds = epoll_wait(pollfd, events, curfds, -1);
		for (n = 0; n < nfds; ++n)
		{
			if (events[n].data.fd == skt_ser)
			{
				new_fd = accept(skt_ser,0,0);
				if (new_fd < 0)
				{
					plog(4, "accept err:%s\r\n", strerror(errno));
					sleep(2);
					continue;
				}
				else if(curfds==MAXEPOLLSIZE-1)
						{
							close(new_fd);
							continue;
						}
				plog(0, "New class connected in, socket:%d!\r\n", new_fd);
				ev.events = EPOLLIN;
				ev.data.fd = new_fd;
				if (epoll_ctl(pollfd, EPOLL_CTL_ADD, new_fd, &ev) < 0)
				{
					plog(4, "PUT new class(fd:%d) in epoll FAILED!!! Close the class:%s\r\n", new_fd, strerror(errno));
					close(new_fd);
					continue;
				}
				curfds++;
			}
			else
			{
				if (handle_message(events[n].data.fd) < 0)
				{
					epoll_ctl(pollfd, EPOLL_CTL_DEL, events[n].data.fd,&ev);
					close( events[n].data.fd );
					if(curfds>1) curfds--;
				}
			}
		}
	}
}

void RTMP_MAIN()
{
	char ads[50];
	int id=8;
	prctl(PR_SET_NAME, "RTMP-MAIN", NULL, NULL, NULL);
	get_path("[RTMP-LOG]", "/var/log/drs8/RTMP-LIVE", ads, &id);
	if( init_LOG(msgid, id, ads, "[RTMP-MAIN]") )
		plog(4, "init LOG error. This is [RTMP-MAIN]!!!\r\n");
	signal(SIGPIPE, SIG_IGN);
	state_init();
	rtmpmain();
}

void RTMP_EXEC()
{	
	char ads[50];
	int id=8;
	sprintf(log_exec, "%d", msgid);
	prctl(PR_SET_NAME, "RTMP-EXECUTE", NULL, NULL, NULL);
	get_path("[RTMP-LOG]", "/var/log/drs8/RTMP-LIVE", ads, &id);
	if( init_LOG(msgid, id, ads, "[RTMP-EXECUTE]") )
		plog(4, "init LOG error. This is [RTMP-EXECUTE]!!!\r\n");
	
struct sigaction sa_usr;
sa_usr.sa_flags = 0;
sa_usr.sa_handler = sig_chld_rtmp;   //信号处理函数
sigaction(SIGCHLD, &sa_usr, NULL);
	state_init();
	plog(0, "Program Start!!!\r\n");
	rtmpsever();
}
