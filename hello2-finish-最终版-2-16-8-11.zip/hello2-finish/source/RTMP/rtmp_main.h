#ifndef _RTMP_MAIN_H_
#define _RTMP_MAIN_H_

#define SERVER_PROT			9970
#define WEB_TO_DRS_HEAD		'R'
#define DRS_TO_WEB_HEAD		'T'

typedef struct class{
	pid_t pid;
	unsigned char ans;	//1 开启；2 关闭； 3 重启
	unsigned char room;
	unsigned int ip_addr;
	unsigned char rtmp_path[256];
	struct class* next;
}class;

typedef struct stream_cmd_pakg{
	unsigned char chan;						//命令号
	unsigned char cmd;						//时间
	unsigned int ip_addr;						//ip地址
	unsigned int port;
}stream_cmd_pakg;

typedef struct List{
	struct class* head;
	struct class* end;
	int num;
}List;

#define UNIX_PATH_MAX 108
#define MAXEPOLLSIZE 256

//error define
// #define SOCKET_ERR			201
// #define BIND_ERR			202
// #define LISTEN_ERR			203
// #define CONNECT_ERR			204
// #define ACCEPT_ERR			205
// #define FILE_CREAT_ERR		206
// #define RECEV_ERR			207
// #define NETWORK_ERR			208
// #define WRITE_ERR			209
// #define NETWORK_BREAK		210
// #define CORE_BREAK			211
// #define WRITE_ERR2			212
// #define WRITE_ERR3			213
// #define READ_ERR			214
// #define PACKET_ERR			215
// #define UNKNOW_ERR			216

#define OPEN_INPUT_ERR			201
#define FIND_STREAM_INFO_ERR	202
#define WRITE_ERR				203
#define NEW_STREAM_ERR			204
#define COPY_STREAM_ERR			205
#define AVIO_OPEN_ERR			206
#define WRITE_HEAD_ERR			207
#define READ_ERR				208
#define PACKET_ERR				209
#define UNKNOW_ERR				216
#define PREPARE					254
#define RUNING					255


#endif