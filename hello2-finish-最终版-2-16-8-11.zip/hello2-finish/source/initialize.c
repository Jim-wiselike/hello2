#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/statfs.h> 

#include "init.h"

typedef struct fun_names{
	int num;
	char** fun;
}fun_names;

static int msgid0=0;
static char msg_head[20]={0};

static void msg_send(int type, char *msg)			//消息队列发送函数
{
	msg_buf mbuf;
	mbuf.type=777;
	mbuf.data.type=type;
	sprintf(mbuf.data.msg,"%s",msg);
	msgsnd(msgid0, &mbuf, sizeof(mbuf.data), 0);
}

void plog(int type, const char *fmt, ...) 
{
	va_list args;
	char sprint_buf[MSG_L]={0};
	int l=strlen(msg_head);

	sprintf(sprint_buf, "%s", msg_head);
	if(type==6)
	{
		sprintf(sprint_buf, "------------------\r\n");
		l=0;
	}
	va_start(args, fmt);
	vsprintf(sprint_buf+l, fmt, args);
	va_end(args);
	msg_send(type, sprint_buf);
}

static void msg_start(int msgid ,int id, const char *path)			//消息队列发送函数
{
	msg_buf_s mbuf={0};
	mbuf.type = 666;
	mbuf.data.id = id;
	mbuf.data.cmd = START;
	if(path!=NULL)sprintf(mbuf.data.path, "%s", path);
	msgsnd(msgid, &mbuf, sizeof(mbuf.data), 0);
}

static int msg_recv_init(int msgid, int id)			//消息队列接收函数
{
	msg_buf_s mbuf;
	bzero(&mbuf,sizeof(msg_buf_s));
	msgrcv(msgid, &mbuf, sizeof(mbuf.data), id, 0);
	return mbuf.data.cmd;
}

int msg_init(int* msgid, int cp)		//创建消息队列函数
{
	key_t key;
	key=ftok(".",cp);
	if(key==-1)
	{
		plog(4, "[---]Ftok err:%s\r\n", strerror(errno));
		return 1;
	}
	
	*msgid=msgget(key,IPC_CREAT|IPC_EXCL|0666);	//根据线程id创建消息队列
	if(*msgid==-1)
	{
		*msgid=msgget(key,0);						//如果消息队列存在，打开它
		if(*msgid==-1)
		{
			plog(4, "[---]Msgget id failed!!!\r\n");
			return 2;
		}
	}
	return 0;
}

int init_LOG(int msgid, int id, char* path,const char* head)
{
	int r=0;
	do{
		msg_start(msgid ,id, path);
		r = msg_recv_init(msgid, id);
	}while( r==RETRY );
	if(r==SUCCESS)msg_init(&msgid0, id);
	else return 1;
	plog(0, "[---]LOG start, id:%d!!!\r\n", id);
//printf("msgid=%d, path=%s\r\n\r\n", msgid0, path);
	sprintf(msg_head, "%s", head);
	return 0;
}

int init_LOG2(int msgid, int id, char* path,const char* head)
{
	msg_init(&msgid0, id);
	sprintf(msg_head, "%s", head);
	return 0;
}

fun_names get_argv(int num, ...)
{
	fun_names funs;
	va_list args;
	int i;
	char** argv = NULL;

	funs.num=num;
	argv = (char**)malloc( sizeof(char*)*num);
	va_start(args, num);
	for(i=0; i<num; i++)
	{
		argv[i]=va_arg(args, char*);
	}
	va_end(args);
	
	funs.fun=argv;
	return funs;
}

int CreateDirectoryEx(char *sPathName)
{  
    char DirName[FILE_PATH_L];
	int i,len = strlen(sPathName);
	if(sPathName[len-1]!='/')      
    strcat(sPathName,"/"); 
    strcpy(DirName,sPathName);
    len = strlen(DirName);      
    for(i=1;i<len;i++)      
    {      
        if(DirName[i]=='/')      
        {      
            DirName[i] = 0;      
            if(access(DirName,0) != 0)      
            {      
                if(mkdir(DirName,0755) == -1)      
                {       
                    plog(4, "[LOG]Create Directory ERR:%s\r\n", strerror(errno));
                    return -1;       
                }      
            }
            DirName[i] = '/';      
         }      
  }
  return 0;      
}

void del_msg()
{
	msgctl(msgid0,IPC_RMID,0);
	plog(5, "[---]LOG closed!!!\r\n");
}

int read_file(const char* search, FILE* fp, char* val, int* id)
{
	char tmp1[50]={0};
	char tmp2[50]={0};
	char tmp3[50]={0};
	char tmp4[50]={0};
	char * line = NULL;
	size_t len = 0;
	if( id==NULL )id=(int*)&len;
	while(getline(&line, &len, fp) != EOF)
	{
		if(line[0]=='#') continue;
		sscanf(line, "%s =%s %s =%s", tmp1, tmp2, tmp3, tmp4);
		if( !strcmp(tmp1, search) )
		{
			strcpy(val, tmp2);
			if( !strcmp(tmp3, "id") )
			{
				if( atoi(tmp4)<255 ) *id=atoi(tmp4);
			}
			free(line);
			return 1;
		}
		bzero(tmp3, sizeof(tmp3));
		bzero(tmp4, sizeof(tmp4));
	}
	free(line);
	return 0;
}

void get_path(const char *key, const char *def, char* ans, int *id)
{
	FILE* fp=NULL;
	int fd;
	char conf[70];
	if( id==NULL )sprintf(conf, "%s = %s\r\n", key, def);
	else sprintf(conf, "%s = %s\t\tid = %d\r\n", key, def, *id);
	fp=fopen("./drs8.conf", "rb");
	if(fp==NULL)
	{
		fd=open("drs8.conf",O_RDWR|O_CREAT|O_APPEND,0666);
		write(fd, "#This file include the configurations.\r\n", strlen("#This file include the configurations.\r\n"));
		write(fd, "#form:\r\n", strlen("#form:\r\n"));
		write(fd, "#[Item] space [=] space [method]\r\n", strlen("#[Item] space [=] space [method]\r\n"));
		write(fd, "#If it is the path for LOG, please add the ID!\r\n", strlen("#If it is the path for LOG, please add the ID!\r\n"));
		write(fd, "#form:\r\n", strlen("#form:\r\n"));
		write(fd, "#[Item] space [=] space [method] tabs [id] space [=] space [number]\r\n\r\n\r\n", strlen("#[Item] space [=] space [method] tabs [id] space [=] space [number]\r\n\r\n\r\n"));
		write(fd , conf , strlen(conf));
		close(fd);
		strcpy(ans, def);
		return;
	}
	else
	{
		if( !read_file(key, fp, ans, id) )
		{
			fd=open("drs8.conf",O_RDWR|O_APPEND,0666);
			write(fd , conf , strlen(conf));
			close(fd);
			strcpy(ans, def);
		}
		fclose(fp);
		return;
	}
}

int free_space(const char* path)
{
	struct statfs disk_info;  
      
    statfs(path, &disk_info);  
    unsigned long long available_disk = disk_info.f_bavail * disk_info.f_bsize / 1024000;   //可用空间大小  
    if( available_disk<101 ) return available_disk==0?1:(int)available_disk;
	return 0;
}
