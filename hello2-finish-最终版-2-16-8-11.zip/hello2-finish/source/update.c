#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include "initialize.h"
int msgid;
int number;
char update_path[20];


int chk_size=0;

void add(int size)
{
	chk_size+=size;
}

struct execute{
	char FileName[PATH_MAX];
	char filepath[PATH_MAX];
	int type;
}exec_file;

int get_file_size(const char *filepath)  
{  
	int filesize = 0;  
	struct stat statbuff;  

	if (stat(filepath, &statbuff) < 0)
	{  
		return filesize;  
	}
	else
	{  
		filesize = statbuff.st_size;  
	}
	return filesize;  
}

int isFile(const char* FileName)			//判断文件是否属于文本文件
{
	char name[8]={0};
	int l = strlen(FileName);
	int flag=0, i;
	if( l<3 )
	{
		plog(4,"file name err!!:%s\r\n", FileName);
		return 0;			//直接过滤文件名短的非文本文件
	}
	else
	{
		for(i=0; i<l; i++)
			if(FileName[i]=='.')
			{
				flag++;
				break;
			}
		if( !flag ) return 1;		//ELF
		snprintf( name, 4, "%s", FileName + l - 3 );
		if( !strcmp( name, ".sh") )	//通过比较后缀名的方式判断是否为文本文件
			return 2;				//sh
		else if( !strcmp( name, ".gz") )
		{
			if(l<8)
			{
				plog(4,"file name to short for .gz file:%s!\r\n", FileName);
				return 0;
			}
			snprintf( name, 8, "%s", FileName + l - 7 );
			if( !strcmp( name, ".tar.gz") )
				return 3;			//TAR.GZ
			plog(4,"Can't handle .gz file:%s, transform to .tar.gz file and try again.\r\n", FileName);
			return 0;
		}
		plog(4,"skip unknow file type:%s\r\n", FileName);
		return 0;
	}
	plog(5,"skip unknow FILE type:%s\r\n", FileName);
	return 0;
}

void chk_exec_files(const char *filepath, const char *FileName)
{
	int res=0;
	res = isFile(FileName);
	switch( res )
	{
		case 1:
		{
			plog(4,"catch ELF file\r\n");
			sprintf(exec_file.FileName, "%s", FileName);
			sprintf(exec_file.filepath, "%s", filepath);
			exec_file.type = 1;
			break;
		}
		case 2:
		{
			plog(0,"catch .sh file\r\n");
			sprintf(exec_file.FileName, "%s", FileName);
			sprintf(exec_file.filepath, "%s", filepath);
			exec_file.type = 2;
			break;
		}
		case 3:
		{
			plog(0,"catch .tar.gz file\r\n");
			if(exec_file.type==0)
			{
				sprintf(exec_file.FileName, "%s", FileName);
				sprintf(exec_file.filepath, "%s", filepath);
				exec_file.type = 3;
			}
			break;
		}
		default: return;
	}
	res = chmod(filepath, 0777);
	if( -1==res )plog(4,"chmod for file:%s err! %s\r\n", filepath, strerror(errno));
}

void run()
{
	char exec_tmp[PATH_MAX];
	switch( exec_file.type )
	{
		case 1:
		{
			if( fork()==0 )
			{
				sprintf(exec_tmp, "%s &", exec_file.filepath);
				plog(3,"run ELF file: %s\r\n", exec_tmp);
				system(exec_tmp);
			}
			break;
		}
		case 2:
		{
			system(exec_file.filepath);
			sprintf(exec_tmp, "rm -rf %s*", exec_file.filepath);
			plog(3,"del sh file:%s\r\n", exec_tmp);
			system(exec_tmp);
			break;
		}
		case 3: 
		{
			sprintf(exec_tmp, "tar -xzf %s -C %s", exec_file.filepath, update_path);
			plog(3,"uncompress file:%s\r\n", exec_tmp);
			system(exec_tmp);
			exec_file.filepath[strlen(exec_file.filepath)-7] = 0;
			sprintf(exec_tmp, "%s/*.sh", update_path);
			plog(3,"run: %s\r\n", exec_tmp);
			system(exec_tmp);
			sprintf(exec_tmp, "rm -rf %s*", exec_file.filepath);
			plog(3,"run: %s\r\n", exec_tmp);
			system(exec_tmp);
			sprintf(exec_tmp, "rm -rf %s/*.sh", update_path);
			plog(3,"run: %s\r\n", exec_tmp);
			system(exec_tmp);
			break;
		}
		default: break;
	}
	exec_file.FileName[0]=0;
	exec_file.filepath[0]=0;
	exec_file.type = 0;
}

void ListAllFiles(char *dirname, int flag)			//遍历所有文件函数
{
	char path[PATH_MAX];				//存放文件路径
	struct dirent *filename;
	DIR *dir;
 
	dir = opendir(dirname);				//打开文件夹函数
	if(dir == NULL)
	{
		plog(4, "Error:%s:%m!\r\n", dirname);	//打开错误，则输出错误信息
		return;
	}
 
	while((filename = readdir(dir)) != NULL)	//循环遍历文件夹里内容
	{
  //跳过目录结构下面的两个.和..的目录
		if(!strcmp(filename->d_name,".") || !strcmp(filename->d_name,".."))
			continue;

  		//非常好用的一个函数，比什么字符串拼接什么的来的快的多
  		sprintf(path,"%s/%s",dirname,filename->d_name);

  		struct stat s;
		lstat(path,&s);
  
		if(S_ISDIR(s.st_mode))
		{
			ListAllFiles(path, flag);		//递归调用
		}
		else
			if(flag==0)
				add(get_file_size(path));
			else
				chk_exec_files(path, filename->d_name);
	}
	closedir(dir);					//关闭目录
}

void main(int argc, char** argv)
{
	char ads[50];
	int id=4;
	msgid=atoi(argv[1]);
	printf("UPDATE:\targc=%d, argv[1]=%d\r\n", argc, msgid);
	get_path("[UPDATE-LOG]", "/var/log/drs8/UPDATE", ads, &id);
	get_path("[UPDATE-PATH]", "./update/", update_path, NULL);
	init_LOG(msgid, id, ads, "[UPDATE]");
	plog(6, "\r\n---------------UPDATE new start----------------------\r\n");
	int size_before=0;
	chk_size = 0;
	int flag=0;
	plog(0,"Waiting for update file...\r\n");
	while(1)
	{
		sleep(3);
		if( access(update_path, F_OK)!=0 )
			mkdir(update_path,0755);
		chk_size=0;
		ListAllFiles(update_path, 0);
		while( chk_size!=size_before )
		{
			size_before = chk_size;
			sleep(1);
			chk_size=0;
			ListAllFiles(update_path, 0);
			flag=1;
		}
		if(flag)
		{
			plog(3,"prepare to update!\r\n");
			flag=0;
			ListAllFiles(update_path, 1);
			run();
//			system("reboot");
		}
	}
}