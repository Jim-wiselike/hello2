#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <stdarg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>

#include "init.h"
typedef struct fun_names{
	int num;
	char** fun;
}fun_names;

static int msgid0;
static char msg_head[20]={0};

static void msg_send(int type, char *msg)			//消息队列发送函数
{
	msg_buf mbuf;
	mbuf.type=777;
	mbuf.data.type=type;
	sprintf(mbuf.data.msg,"%s",msg);
	msgsnd(msgid0, &mbuf, sizeof(mbuf.data), 0);
}

void plog(int type, const char *fmt, ...) 
{
	va_list args;
	char sprint_buf[MSG_L]={0};
	int l=strlen(msg_head);

	sprintf(sprint_buf, msg_head);
	if(type==3)
	{
		sprintf(sprint_buf, "------------------\r\n");
		l=0;
	}
	va_start(args, fmt);
	vsprintf(sprint_buf+l, fmt, args);
	va_end(args);
	msg_send(type, sprint_buf);
}

static void msg_start(int msgid ,int id, const char *path)			//消息队列发送函数
{
	msg_buf_s mbuf={0};
	mbuf.type = 666;
	mbuf.data.id = id;
	mbuf.data.cmd = START;
	if(path!=NULL)sprintf(mbuf.data.path, "%s", path);
	msgsnd(msgid, &mbuf, sizeof(mbuf.data), 0);
}

static int msg_recv_s(int msgid, int id)			//消息队列接收函数
{
	msg_buf_s mbuf;
	bzero(&mbuf,sizeof(msg_buf_s));
	msgrcv(msgid, &mbuf, sizeof(mbuf.data), id, 0);
	return mbuf.data.cmd;
}

int msg_init(int* msgid, int cp)		//创建消息队列函数
{
	key_t key;
	key=ftok(".",cp);
	if(key==-1)
	{
		plog(1, "[---]Ftok err:%s\r\n", strerror(errno));
		return 1;
	}
	
	*msgid=msgget(key,IPC_CREAT|IPC_EXCL|0666);	//根据线程id创建消息队列
	if(*msgid==-1)
	{
		*msgid=msgget(key,0);						//如果消息队列存在，打开它
		if(*msgid==-1)
		{
			plog(1, "[---]Msgget id failed!!!\r\n");
			return 2;
		}
	}
	return 0;
}

int init_LOG(int msgid, int id, const char* path, char* head)
{
	int r;
	do{
		msg_start(msgid ,id, path);
		r = msg_recv_s(msgid, id);
	}while( r==RETRY );
	if(r==SUCCESS)msg_init(&msgid0, id);
	else return 1;
	plog(0, "[---]LOG start, id:%d!!!\r\n", id);
	sprintf(msg_head, "%s", head);
	return 0;
}

fun_names get_argv(int num, ...)
{
	fun_names funs;
	va_list args;
	int i;
	char** argv = NULL;

	funs.num=num;
	argv = (char**)malloc( sizeof(char*)*num);
	va_start(args, num);
	for(i=0; i<num; i++)
	{
		argv[i]=va_arg(args, char*);
	}
	va_end(args);
	
	funs.fun=argv;
	return funs;
}

int CreateDirectoryEx(char *sPathName)
{  
    char DirName[FILE_PATH_L];
	int i,len = strlen(sPathName);
	if(sPathName[len-1]!='/')      
    strcat(sPathName,"/"); 
    strcpy(DirName,sPathName);
    len = strlen(DirName);      
    for(i=1;i<len;i++)      
    {      
        if(DirName[i]=='/')      
        {      
            DirName[i] = 0;      
            if(access(DirName,0) != 0)      
            {      
                if(mkdir(DirName,0755) == -1)      
                {       
                    plog(1, "[LOG]Create Directory ERR:%s\r\n", strerror(errno));
                    return -1;       
                }      
            }
            DirName[i] = '/';      
         }      
  }
  return 0;      
}

void del_msg()
{
	msgctl(msgid0,IPC_RMID,0);
	plog(0, "[---]LOG closed!!!\r\n");
}
