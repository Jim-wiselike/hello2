﻿//This is only used for testing.

#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<fcntl.h>
#include <string.h>

#include "initialize.h"

int msgid;

void main(int argc, char** argv)
{
//	msgid=atoi(argv[1]);
//	init_LOG(msgid, 100, "/root/SEG");
	int sfd;
	int r;
	int len;
	unsigned char buf[256],rev_buf[256];
	int i,n;
	struct sockaddr_in adds={0},addr={0};
	
//	rfd=socket(AF_INET,SOCK_STREAM,0);
//	if(sfd==-1) printf("socket err:%m\r\n"),close(rfd),exit(-1);
//		else printf("socket success!\r\n");
//
//	addr.sin_family=AF_INET;
//	addr.sin_port=htons(16780);
//	inet_aton("10.1.58.125",&addr.sin_addr);
	
//	r=bind(rfd,(struct sockaddr*)&addr,sizeof(addr));
//	if(r==-1) printf("bind err:%m\r\n"),close(rfd),exit(-1);
//		else printf("bind success!\r\n");
	
//----------------------------------------------
		
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1) printf("socket err:%m\r\n"),close(sfd),exit(-1);
		else printf("socket success!\r\n");

	adds.sin_family=AF_INET;
	adds.sin_port=htons(9968);
	inet_aton("127.0.0.1",&adds.sin_addr);
	r=connect(sfd,(struct sockaddr*)&adds,sizeof(adds));
	if(r==-1) printf("connect err:%m\r\n"),close(sfd),exit(-1);
		else printf("connect success!\r\n");
	
//	r=listen(sfd,10);
//	if(r==-1) printf("listen err:%m\r\n"),close(sfd),exit(-1);
//		else printf("listen success!\r\n");
	
	
//	cfd=accept(sfd,0,0);
//	if(cfd==-1) printf("accept err:%m\r\n"),close(sfd),exit(-1);
//		else printf("File sending!\r\n");
int y=0;
int x=432000;
//for(y=0;y<x;y++)
{
n=1;
buf[0]='S';
buf[1]=n;
sprintf(buf+2 , "hey.mp4");
sprintf(buf+26, "hey1.mp4");

buf[50]=1;
buf[51]=18;
//{0,0,0,0,0,152,150,128,0,0,0,0,1,49,45,0};
buf[52]=0;
buf[53]=0;
buf[54]=0;
buf[55]=0;
buf[56]=100;
buf[57]=152;
buf[58]=150;
buf[59]=128;

buf[60]=10;
buf[61]=100;
buf[62]=100;
buf[63]=100;
buf[64]=1;
buf[65]=49;
buf[66]=45;
buf[67]=0;

buf[68]=1;
buf[69]=18;
//sprintf(buf+70, "1234567887654321");
//memcpy(buf+70, tep, 13);
//sleep(1);
	r=send(sfd,buf,68,0);
	r=recv(sfd,buf,26, 0);
	printf( "test:%c:%d\t%s\r\n", buf[0], buf[1], buf+2);
	usleep(50000);
//----------------------------------------------
/*
	r=bind(sfd,(struct sockaddr*)&adds,sizeof(adds));
	if(r==-1) printf("connect err:%m\r\n"),close(sfd),exit(-1);
		else printf("connect success!\r\n");
	r=listen(sfd,10);
	if(r==-1) printf("listen err:%m\r\n"),close(rfd),exit(-1);
		else printf("listen success!\r\n");
	
	cfd=accept(sfd,0,0);
	r=recv(cfd,rev_buf,256,MSG_WAITALL);
	if(r==-1) printf("rev_buf err:%m\r\n"),close(rfd),close(cfd),close(sfd),exit(-1);
		else printf("rev_buf:%s\r\n",rev_buf);
		
*/
//	close(rfd);
//	close(cfd);
}
	close(sfd);
	printf("OK!\r\n");
}
