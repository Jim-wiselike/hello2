//This is only used for testing.

#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<fcntl.h>

int main()
{
	int sfd;
	int r;
	int len;
	unsigned char buf[256],rev_buf[256];
	int i,n;
	struct sockaddr_in adds={0},addr={0};
	
//	rfd=socket(AF_INET,SOCK_STREAM,0);
//	if(sfd==-1) printf("socket err:%m\r\n"),close(rfd),exit(-1);
//		else printf("socket success!\r\n");
//
//	addr.sin_family=AF_INET;
//	addr.sin_port=htons(16780);
//	inet_aton("10.1.58.125",&addr.sin_addr);
	
//	r=bind(rfd,(struct sockaddr*)&addr,sizeof(addr));
//	if(r==-1) printf("bind err:%m\r\n"),close(rfd),exit(-1);
//		else printf("bind success!\r\n");
	
//----------------------------------------------
		
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1) printf("socket err:%m\r\n"),close(sfd),exit(-1);
		else printf("socket success!\r\n");

	adds.sin_family=AF_INET;
	adds.sin_port=htons(9972);
	inet_aton("127.0.0.1",&adds.sin_addr);
	r=connect(sfd,(struct sockaddr*)&adds,sizeof(adds));
	if(r==-1) printf("connect err:%m\r\n"),close(sfd),exit(-1);
		else printf("connect success!\r\n");
	
//	r=listen(sfd,10);
//	if(r==-1) printf("listen err:%m\r\n"),close(sfd),exit(-1);
//		else printf("listen success!\r\n");
	
	
//	cfd=accept(sfd,0,0);
//	if(cfd==-1) printf("accept err:%m\r\n"),close(sfd),exit(-1);
//		else printf("File sending!\r\n");
int j;
for(j=11; j<12; j++)
{
	bzero(buf,sizeof(buf));
	n=1;
	buf[0]='Z';
	buf[1]=0;
	for(i=0;i<n;i++)
	{
//		sprintf(buf+2, "%c%c%c%c%c%c%s", 1,255, 127, 0, 0, 1, "ffffffffffffff");
		r=send(sfd,buf,1,0);
//		printf("%d:%m\r\n", j);
r=recv(sfd,buf,256,0);
printf("%d\r\n", buf[255]);
//		puts(buf);
	}
r=recv(sfd,buf,256,0);
//	sleep(1);
}
//----------------------------------------------
/*
	r=bind(sfd,(struct sockaddr*)&adds,sizeof(adds));
	if(r==-1) printf("connect err:%m\r\n"),close(sfd),exit(-1);
		else printf("connect success!\r\n");
	r=listen(sfd,10);
	if(r==-1) printf("listen err:%m\r\n"),close(rfd),exit(-1);
		else printf("listen success!\r\n");
	
	cfd=accept(sfd,0,0);
	r=recv(cfd,rev_buf,256,MSG_WAITALL);
	if(r==-1) printf("rev_buf err:%m\r\n"),close(rfd),close(cfd),close(sfd),exit(-1);
		else printf("rev_buf:%s\r\n",rev_buf);
		
*/
//	close(rfd);
//	close(cfd);

	close(sfd);
	printf("OK!\r\n");
}
