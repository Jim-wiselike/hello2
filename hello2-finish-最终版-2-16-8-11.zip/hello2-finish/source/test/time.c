#include <stdio.h>
#include <sys/time.h>
int main()
{
  struct  timeval  time;
  unsigned long timer,timer2;
while(1)
{
  gettimeofday(&time,NULL);
  timer = 1000000 * time.tv_sec+ time.tv_usec;
  printf("timer = %ld us\r\n",timer);
  
  usleep(1060000);
  printf("hello world!\r\n");
  gettimeofday(&time,NULL);
  timer2 = 1000000 * time.tv_sec+ time.tv_usec;
  printf("timer2 = %ld us\r\n",timer2);
  printf("timer- = %ld us\r\n",timer2-timer);
  if(timer2-timer<0)puts("eeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
}
  return 0;
} 
