//This is only used for testing.

#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<fcntl.h>

int main()
{
	int sfd;
	int r;
	int len;
	unsigned char buf[256],rev_buf[256];
	int i,n;
	struct sockaddr_in adds={0},addr={0};
	
//	rfd=socket(AF_INET,SOCK_STREAM,0);
//	if(sfd==-1) printf("socket err:%m\r\n"),close(rfd),exit(-1);
//		else printf("socket success!\r\n");
//
//	addr.sin_family=AF_INET;
//	addr.sin_port=htons(16780);
//	inet_aton("10.1.58.125",&addr.sin_addr);
	
//	r=bind(rfd,(struct sockaddr*)&addr,sizeof(addr));
//	if(r==-1) printf("bind err:%m\r\n"),close(rfd),exit(-1);
//		else printf("bind success!\r\n");
	
//----------------------------------------------
int j=0;
while(1)
{		
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1){printf("socket err:%m\r\n"),close(sfd);break;}
		else printf("socket success!\r\n");

	adds.sin_family=AF_INET;
	adds.sin_port=htons(9966);
	inet_aton("127.0.0.1",&adds.sin_addr);
	
	
//	r=listen(sfd,10);
//	if(r==-1) printf("listen err:%m\r\n"),close(sfd),exit(-1);
//		else printf("listen success!\r\n");
	
	
//	cfd=accept(sfd,0,0);
//	if(cfd==-1) printf("accept err:%m\r\n"),close(sfd),exit(-1);
//		else printf("File sending!\r\n");


	r=connect(sfd,(struct sockaddr*)&adds,sizeof(adds));
	if(r==-1){printf("connect err:%m\r\n"),close(sfd);break;}
		else printf("connect success!\r\n");

	bzero(buf,sizeof(buf));
	n=1;
	buf[0]='W';
	buf[1]=0;
	r=send(sfd,buf,1,0);
//	r=recv(sfd,buf,256,0);
sleep(1);
	close(sfd);
sleep(2);
j++;
}
printf("j=%d\n", j);
	printf("OK!\r\n");
}
