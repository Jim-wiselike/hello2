#ifndef _INITIALIZE_H_
#define _INITIALIZE_H_

#include "init.h"

extern int msgid;

typedef void (*Fun)();

typedef struct plugin_vel{
	char path[FILE_PATH_L];
	char funname[20];
	int pid;
	int msgid;
}plugin_vel;

typedef struct fun_names{
	int num;
	char** fun;
}fun_names;

typedef fun_names (*get_fun)();

int msg_init(int* msgid, int cp);
void plog(int type, const char *fmt, ...);
int init_LOG(int msgid, int id, const char* path, char* head);
fun_names get_argv(int num, ...);
int CreateDirectoryEx(char *sPathName);

#endif





