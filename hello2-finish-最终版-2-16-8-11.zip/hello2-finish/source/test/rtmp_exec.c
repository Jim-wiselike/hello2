﻿#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/socket.h>

#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libavutil/avstring.h>
#include <libavutil/avstring.h>
#include <libavutil/timestamp.h>

#include "../initialize.h"
#include "../RTMP/rtmp_main.h"
unsigned char *monitor=NULL;
int msgid=0;
#define MAX_STREAM_NUM  10

typedef struct st_StreamMapping
{
	enum AVMediaType type;
	int output_index;
} StreamMapping;
int rtmp_living(char *in_stream, char *out_stream, char num)	//aac,h264
{
	AVOutputFormat *ofmt = NULL;
	AVFormatContext *ifmt_ctx = NULL, *ofmt_ctx = NULL;
	AVBitStreamFilterContext *bsfc = NULL;
    AVPacket pkt, out_pkt;
	StreamMapping map_table[MAX_STREAM_NUM];
    int ret = 0, i, output_index = 0, init_keyframe = 0;
	int videoindex=-1;
	AVRational vtimebase;
	AVRational atimebase;
	
	//set log level
	av_log_set_level(AV_LOG_FATAL);

	av_register_all();
	avformat_network_init();
	
	if ((ret = avformat_open_input(&ifmt_ctx, in_stream, NULL, 0))<0)
	{
        plog(4, "Could not open input file '%s'.\r\n", in_stream);
        ret = OPEN_INPUT_ERR;
        goto end;
	}

	if ((ret = avformat_find_stream_info(ifmt_ctx, NULL))<0)
	{
        plog(4, "Failed to retrieve input streams information.\r\n");
		ret = FIND_STREAM_INFO_ERR;
        goto end;
	}

	avformat_alloc_output_context2(&ofmt_ctx, NULL, "flv", out_stream); //RTMP
    if (!ofmt_ctx) {
        plog(4, "Could not create output context.\r\n");
        ret = WRITE_ERR;
        goto end;
	}

	ofmt = ofmt_ctx->oformat;
 	for (i = 0; i < ifmt_ctx->nb_streams; i++) {
		AVStream *in_stream = ifmt_ctx->streams[i];
		AVStream *out_stream = NULL;

		map_table[i].type = in_stream->codec->codec_type;
		map_table[i].output_index = MAX_STREAM_NUM;
		
		if ( in_stream->codec->codec_type != AVMEDIA_TYPE_VIDEO && in_stream->codec->codec_type != AVMEDIA_TYPE_AUDIO)
			continue;
		if (in_stream->codec->codec_type == AVMEDIA_TYPE_VIDEO)
		{	
			vtimebase=ifmt_ctx->streams[i]->time_base;
		}
		else if (in_stream->codec->codec_type == AVMEDIA_TYPE_AUDIO)
		{
			atimebase=ifmt_ctx->streams[i]->time_base;
			uint8_t tmp[2]={18,16};
			in_stream->codec->extradata=tmp;
			in_stream->codec->extradata_size=2;
		}
		map_table[i].output_index = output_index++;

		out_stream = avformat_new_stream(ofmt_ctx, in_stream->codec->codec);
		if (!out_stream) {
			 ret=NEW_STREAM_ERR;
			goto end;
		}
				
		ret = avcodec_copy_context(out_stream->codec, in_stream->codec);
		if (ret < 0) {
			 ret=COPY_STREAM_ERR;
			goto end;
		}
		if (ofmt_ctx->oformat->flags & AVFMT_GLOBALHEADER)
			out_stream->codec->flags |= CODEC_FLAG_GLOBAL_HEADER;

		out_stream->codec->codec_tag=0;
		out_stream->codec->time_base = in_stream->time_base;
	}

	bsfc = av_bitstream_filter_init("aac_adtstoasc");

    if (!(ofmt->flags & AVFMT_NOFILE)) {
        ret = avio_open(&ofmt_ctx->pb, out_stream, AVIO_FLAG_WRITE);
        if (ret < 0) {
            plog(1, "Could not open output file '%s'.\r\n", out_stream);
            ret = AVIO_OPEN_ERR;
            goto end;
        }
    }
	
    ret = avformat_write_header(ofmt_ctx, NULL);
    if (ret < 0) {
        plog(4, "Error occurred when opening output file...\r\n");
        ret = WRITE_HEAD_ERR;
        goto end;
    }
	int64_t audiopts=0;
	int64_t videopts=0;
	int64_t offset=AV_NOPTS_VALUE;
    while (1) {
        AVStream *in_stream, *out_stream;

        ret = av_read_frame(ifmt_ctx, &pkt);
        if (ret < 0){
			ret = READ_ERR;
            break;
		}
		in_stream  = ifmt_ctx->streams[pkt.stream_index];
		out_stream = ofmt_ctx->streams[map_table[pkt.stream_index].output_index];

		
		if (offset==AV_NOPTS_VALUE)
		{
			if (map_table[pkt.stream_index].type == AVMEDIA_TYPE_VIDEO)
			{
				offset=-pkt.pts;
			}
			else
				continue;
		}
		
        // copy packet 
		if (map_table[pkt.stream_index].type == AVMEDIA_TYPE_VIDEO)
		{
			pkt.pts += offset;
			pkt.dts += offset;
			if (pkt.dts>pkt.pts+1/av_q2d(in_stream->time_base))
			{
				pkt.dts=pkt.pts;
			}
			videopts = pkt.pts;
			pkt.pts = av_rescale_q_rnd(pkt.pts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.dts = av_rescale_q_rnd(pkt.dts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.duration = av_rescale_q(pkt.duration, in_stream->time_base, out_stream->time_base);	

			/*char s[100]={0};
			sprintf(s, "H264	%lld		%lld		%10.2f		%10.2f		%d	\n",
				pkt.dts, pkt.pts, (pkt.pts*1000.0)*av_q2d(out_stream->time_base), (pkt.duration*1000*av_q2d(out_stream->time_base)), pkt.duration);
			fwrite(s,strlen(s),1,fp);	*/ 
		}else
		{
			pkt.pts=audiopts;
			pkt.dts=audiopts;
			int oridur=pkt.duration;
			pkt.pts = av_rescale_q_rnd(pkt.pts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.dts = av_rescale_q_rnd(pkt.dts, in_stream->time_base, out_stream->time_base, (enum AVRounding)(AV_ROUND_NEAR_INF|AV_ROUND_PASS_MINMAX));
			pkt.duration = av_rescale_q(pkt.duration, in_stream->time_base, out_stream->time_base);	

			int k0=(audiopts*1000*av_q2d(atimebase)-videopts*1000*av_q2d(vtimebase));
			if((audiopts>0)&&(k0>100))
			{
				/*CString str;
				str.Format("\n delay %d\n",k0);
				OutputDebugString(str);*/
				continue;
			}

			/*char s[100]={0};
			sprintf(s, "AAC	%lld		%lld		%10.2f		%10.2f		%d	%d	%lld	%lld\n",
					pkt.dts, pkt.pts, (pkt.pts*1000.0)*av_q2d(out_stream->time_base), (pkt.duration*1000*av_q2d(out_stream->time_base)), pkt.duration, k0, audiopts, videopts);
			fwrite(s,strlen(s),1,fp);*/

			audiopts+=oridur;
		}	
		pkt.pos = -1;
				
        out_pkt = pkt;
		out_pkt.stream_index = map_table[pkt.stream_index].output_index;

        // process AAC packet 
        if (in_stream->codec->codec_id == AV_CODEC_ID_AAC){
			av_bitstream_filter_filter(bsfc, out_stream->codec, NULL, &out_pkt.data, &out_pkt.size, pkt.data, pkt.size, pkt.flags & AV_PKT_FLAG_KEY);
        }
        ret = av_interleaved_write_frame(ofmt_ctx, &out_pkt);
        if (ret < 0) {
            plog(4, "Error muxing packet.\r\n");
            ret = PACKET_ERR;
            break;
        }//network error
        //av_free_packet(&pkt);
    }

    av_write_trailer(ofmt_ctx);

end:
    avformat_close_input(&ifmt_ctx);

    /* close output */
    if (ofmt_ctx && !(ofmt->flags & AVFMT_NOFILE))
        avio_close(ofmt_ctx->pb);
    avformat_free_context(ofmt_ctx);

    if (bsfc)
	    av_bitstream_filter_close(bsfc);

	sleep(3);
	
    if (ret) {
        plog(4, "Error occurred: %d.\r\n", ret);
        if(ret>0) return ret;
		else return UNKNOW_ERR;
    }
    return 0;
}

void state_init(void)
{
	int fd;
	fd=open("tmp_rtmp",O_RDWR|O_CREAT|O_EXCL,0666);
	if(fd==-1)
	{
		fd=open("tmp_rtmp",O_RDWR);
	}
	ftruncate(fd, 256);
	monitor = mmap(0, 256, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
	close(fd);
}

int stream_pipe_init(void)
{
	int pipe;
	mkfifo("tmp_socket_0.pipe",0666);
	pipe=open("tmp_socket_0.pipe",O_RDWR);
	shutdown(pipe,SHUT_RD);
	return pipe;
}

int connect_streamer(unsigned char classid, unsigned int ip)
{
	int pipe=stream_pipe_init();
	stream_cmd_pakg pkg;
	pkg.chan = classid;						//命令号
	pkg.cmd=1;						//时间
	pkg.ip_addr=ip;						//ip地址
	pkg.port=5223;
	
	return write(pipe,&pkg,sizeof(stream_cmd_pakg));
}

//logid, ip coder, num, ip ser, classname, method
int main(int argc, char** argv)
{
	if(argc!=3)printf("usage: %s in_tcp out_rftmp\n", argv[0]),exit(-1);
	return rtmp_living(argv[1], argv[2], 0);
}
