#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>


int read_file(const char* search, FILE* fp, char* val)
{
	char tmp1[50]={0};
	char tmp2[50]={0};
	char * line = NULL;
	size_t len = 0;
	while(getline(&line, &len, fp) != EOF)
	{
		if(line[0]=='#') continue;
		sscanf(line, "%s =%s", tmp1, tmp2);
		if( !strcmp(tmp1, search) )
		{
			strcpy(val, tmp2);
			free(line);
			return 1;
		}
	}
	free(line);
	return 0;
}

void get_path(const char *key, const char *def, char* ans)
{
	FILE* fp=NULL;
	int fd;
	char conf[70];
	int r;
	sprintf(conf, "%s = %s\r\n", key, def);
	fp=fopen("./drs8.conf", "rb");
	if(fp==NULL)
	{
		fd=open("drs8.conf",O_RDWR|O_CREAT|O_APPEND,0666);
		write(fd, "#This file include the configurations\r\n", strlen("#This file include the configurations\r\n"));
		write(fd, "#form:\r\n", strlen("#form:\r\n"));
		write(fd, "#[Item] space [=] space [method]\r\n\r\n\r\n", strlen("#[Item] space [=] space [method]\r\n\r\n\r\n"));

		write(fd , conf , strlen(conf));
		close(fd);
		strcpy(ans, def);
		return;
	}
	else
	{
		if( !read_file(key, fp, ans) )
		{
			fd=open("drs8.conf",O_RDWR|O_APPEND,0666);
			write(fd , conf , strlen(conf));
			close(fd);
			strcpy(ans, def);
		}
		fclose(fp);
		return;
	}
}

int main()
{
	char address[100];
	get_path("[TS-INIT]", "/var/log/drs8/LOG/", address);
	printf("%s\r\n", address);
	
	printf("strlen:%d\r\nsizeof:%d\r\n",strlen("\r\n\r\n\r\n"), sizeof("\r\n\r\n\r\n"));
}