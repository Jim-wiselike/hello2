//This is only used for testing.

#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<fcntl.h>
#include <signal.h>

int rfd,cfd;
void sig(int signo)
{
	close ( rfd );
	close ( cfd );
	exit(0);
}

int main()
{
	while(1)
	{
	
	int r;
	int len;
	unsigned char buf[256],rev_buf[4096*2];
	int i,n;
	int opt = SO_REUSEADDR;
	struct sockaddr_in adds={0},addr={0};
	
	signal(SIGINT, sig);
	rfd=socket(AF_INET,SOCK_STREAM,0);
	if(rfd==-1) printf("socket err:%m\r\n"),close(rfd),exit(-1);
		else printf("socket success!\r\n");

	setsockopt(rfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
	addr.sin_family=AF_INET;
	addr.sin_port=htons(5223);
	addr.sin_addr.s_addr=htonl(INADDR_ANY); 
	
	r=bind(rfd,(struct sockaddr*)&addr,sizeof(addr));
	if(r==-1) printf("bind err:%m\r\n"),close(rfd),exit(-1);
		else printf("bind success!\r\n");
	
	
	r=listen(rfd,10);
	if(r==-1) printf("listen err:%m\r\n"),close(rfd),exit(-1);
		else printf("listen success!\r\n");
	
	
	cfd=accept(rfd,0,0);
	if(cfd==-1) printf("accept err:%m\r\n"),close(rfd),exit(-1);
		else printf("File sending!\r\n");
int num=0;
while(1)
{
 	r=send(cfd,&num,sizeof(int),0);
	if(r==-1)break;
	usleep(100000);
	num++;
}
//----------------------------------------------

	close(rfd);
	close(cfd);

	printf("OK!\r\n");
}
}
