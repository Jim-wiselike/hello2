//This is only used for testing.

#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<string.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<fcntl.h>
#include<time.h>

int main()
{
	int sfd;
	int r;
	int len;
int y,z;
	unsigned char buf[256],rev_buf[256];
	int i,n;
	struct sockaddr_in adds={0},addr={0};
	int a=127,b=0,c=0,d=1;
	printf("ip=%d.%d.%d.%d\r\n\r\n",a,b,c,d);
	
//	rfd=socket(AF_INET,SOCK_STREAM,0);
//	if(sfd==-1) printf("socket err:%m\r\n"),close(rfd),exit(-1);
//		else printf("socket success!\r\n");
//
//	addr.sin_family=AF_INET;
//	addr.sin_port=htons(16780);
//	inet_aton("10.1.58.125",&addr.sin_addr);
	
//	r=bind(rfd,(struct sockaddr*)&addr,sizeof(addr));
//	if(r==-1) printf("bind err:%m\r\n"),close(rfd),exit(-1);
//		else printf("bind success!\r\n");
	
//----------------------------------------------
		
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1) printf("socket err:%m\r\n"),close(sfd),exit(-1);
		else printf("socket success!\r\n");

	adds.sin_family=AF_INET;
	adds.sin_port=htons(9966);
	inet_aton("127.0.0.1",&adds.sin_addr);
	r=connect(sfd,(struct sockaddr*)&adds,sizeof(adds));
	if(r==-1) printf("connect err:%m\r\n"),close(sfd),exit(-1);
		else printf("connect success!\r\n");
	
//	r=listen(sfd,10);
//	if(r==-1) printf("listen err:%m\r\n"),close(sfd),exit(-1);
//		else printf("listen success!\r\n");
	
	
//	cfd=accept(sfd,0,0);
//	if(cfd==-1) printf("accept err:%m\r\n"),close(sfd),exit(-1);
//		else printf("File sending!\r\n");


time_t t;
struct tm *tm;
char name[15];
char ans[256];
while(1)
{
	puts("1");
	time(&t);
	tm = localtime(&t);
	bzero(buf,sizeof(buf));
	sprintf(name, "%02d-%02d|%02d:%02d:%02d", tm->tm_mon+1, tm->tm_mday,tm->tm_hour,tm->tm_min,tm->tm_sec);
	sprintf(buf, "%c%c%c%c%c%c%c%c%s", 'W', 1,1,0xff, a,b, c, d,name);
	r=send(sfd,buf,22,0);
	r=recv(sfd,buf,256,0);
	sleep(7);
	puts("2");
	r=send(sfd,"W",22,0);
	r=recv(sfd,buf,256,0);
	sleep(7);
	r=send(sfd,"W",22,0);
	r=recv(sfd,buf,256,0);
	puts("3");
	sleep(4);
	r=send(sfd,"W",22,0);
	r=recv(sfd,buf,256,0);
	sprintf(buf, "%c%c%c%c%c%c%c%c%s", 'W', 1,0,0xff, a,b, c, d,name);
	r=send(sfd,buf,22,0);
	r=recv(sfd,buf,256,0);
	sleep(5);
	puts("finish");
}
//	close(rfd);
//	close(cfd);

	close(sfd);
	printf("OK!\r\n");
}
