#ifndef _INIT_H_
#define _INIT_H_

#define START 1
#define END 0
#define RETRY 2
#define SUCCESS 3
#define FAIL 4

#define FILE_PATH_L 255
#define MSG_L 128

typedef struct log_qu{
	int id;
	char path[FILE_PATH_L];
	struct log_qu* next;
}log_qu;

typedef struct msg_buf_s{
	long type;
	struct{
		int id;
		char path[FILE_PATH_L];
		int cmd;
	}data;					//定义消息队列内容
}msg_buf_s;

typedef struct msg_buf{
	long type;
	struct{
		int type;
		char msg[MSG_L+1];
	}data;					//定义消息队列内容
}msg_buf;

typedef struct msg_add{
	int id;
	char path[FILE_PATH_L];
}msg_add;

#endif
