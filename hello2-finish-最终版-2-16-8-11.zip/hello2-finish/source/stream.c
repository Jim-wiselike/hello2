#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <signal.h>
#include <unistd.h>

#include "init.h"
#include "initialize.h"
#include "stream.h"

#define UNIX_PATH_MAX 108

ip_qu* coders=NULL;
unsigned char *monitor=NULL;
unsigned char recv_buf[BUFF_SIZE];

void state_init(void)
{
	int fd;
	fd=open("tmp_dat",O_RDWR|O_CREAT|O_EXCL,0666);
	if(fd==-1)
	{
		fd=open("tmp_dat",O_RDWR);
	}
	ftruncate(fd, 256);
	monitor = mmap(0, 256, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
	monitor[0]='D';
	close(fd);
}

int pipe_init(void)
{
	int fd_pipe;
	mkfifo("tmp_socket_0.pipe",0666);
	fd_pipe=open("tmp_socket_0.pipe",O_RDWR);
	shutdown(fd_pipe,SHUT_WR);
	return fd_pipe;
}

ip_qu* create(ip_qu* head, cmd_pakg* cp)
{
	ip_qu* q = head;
	if(head==NULL)
	{
		q = (ip_qu*)malloc(sizeof(ip_qu));
		q->ip_addr = cp->ip_addr;
		q->port = cp->port;
		q->chan = cp->chan;
		q->next = NULL;
		return q;
	}
	while( q->next!=NULL )
	{
		q = q->next;
	}
	q->next = (ip_qu*)malloc(sizeof(ip_qu));
	q->next->next = NULL;
	q->next->ip_addr = cp->ip_addr;
	q->next->chan = cp->chan;
	q->next->port = cp->port;
	return head;
}

int find(ip_qu* head, cmd_pakg *cp)
{
	if(head==NULL) return 0;
	while(head!=NULL)
	{
		if(head->ip_addr==cp->ip_addr && head->port==cp->port && head->chan==cp->chan) return 1;
		head = head->next;
	}
	return 0;
}

ip_qu* delete(ip_qu* head, cmd_pakg *cp)
{
	ip_qu* before = head;
	ip_qu* del;
	if(head==NULL)return NULL;
	if(before->ip_addr==cp->ip_addr && before->port==cp->port && before->chan==cp->chan)
	{
		head=head->next;
		free(before);
		return head;
	}
	while(before->next!=NULL && (before->next->ip_addr!=cp->ip_addr || before->next->port!=cp->port || before->chan==cp->chan))
	{
		before=before->next;
	}
	if(before->next==NULL)return head;
	if(before->next->next==NULL)
	{
		free(before->next);
		before->next = NULL;
		return head;
	}
	del = before->next;
	before->next = before->next->next;
	free(del);
	return head;
}

con_qu* Close(con_qu* head, con_qu* cp)
{
	con_qu* ret;
	if(head==NULL)return head;
	if(head==cp)
	{
		ret = head->next;
		close(head->fd);
		head->fd = -1;
		free(head);
		return ret;
	}
	while(head!=NULL && head->next!=cp)
		head = head->next;
	ret = cp->next;
	head->next = ret;
	close(cp->fd);
	cp->fd = -1;
	free(cp);
	return ret;
}

con_qu* add(con_qu* head, int fd)
{
	con_qu* q = head;
	if(fd==-1)
	{
		return head;
	}
	if(head==NULL)
	{
		q = (con_qu*)malloc(sizeof(con_qu));
		q->fd = fd;
		q->next = NULL;
		return q;
	}
	while( q->next!=NULL )
	{
		q = q->next;
	}
	q->next = (con_qu*)malloc(sizeof(con_qu));
	q->next->next = NULL;
	q->next->fd = fd;
	return head;
}

int cmd_parse(cmd_pakg *cp)
{
// 	if(cp->cmd)
// 	{
		if(find(coders, cp))
			return 0;
		coders = create(coders, cp);
		return 1;
// 	}
// 	else delete(coders, cp);
// 	return 0;
}

void sig_handler(int signum)
{
    signal(signum, sig_handler);
    plog(0, "STREAM recv client break!\r\n");
}

int stream_connect(int sockfd, const struct sockaddr *addr,
                      socklen_t addrlen, struct timeval timeout)
{
	int ret;
	fd_set fds;
	int maxfd;
	int flags;
	flags = fcntl(sockfd, F_GETFL, 0);
	fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);  
	ret = connect(sockfd, addr, addrlen);

	if (0 == ret) {
		fcntl(sockfd, F_SETFL, flags);
		return sockfd;
	} 

	FD_ZERO(&fds); 
	FD_SET(sockfd, &fds);  //把先前的套接字加到读集合里面 
	
	ret = select(sockfd+1, &fds, 0, 0, &timeout); 
	if (ret < 0) return -1;
	else if (0 == ret) return -1;
	else fcntl(sockfd, F_SETFL, flags);
	return sockfd;
}

int StartCoding(cmd_pakg *cp)
{
	plog(0, "Connecting the coder\r\n");
	struct sockaddr_in addr = {0};
	int r = 0;
	struct timeval timeout;
	timeout.tv_sec = 2; 
	timeout.tv_usec = 0; 
//Start socket
	int server = socket( AF_INET , SOCK_STREAM , 6 );
	if ( server==-1 )
	{
		close ( server );
		plog(4, "create socket err for CODER(%u.%u.%u.%u):%s\r\n", cp->ip_addr%256,(cp->ip_addr>>8)%256, (cp->ip_addr>>16)%256, cp->ip_addr>>24, strerror(errno));
		return -1;
	}
//Start connect
	addr.sin_family = AF_INET;
	addr.sin_port   = htons( cp->port );
	addr.sin_addr.s_addr = cp->ip_addr;
	r = stream_connect( server , (struct sockaddr*) &addr , sizeof(addr),  timeout);
	if ( r==-1 )
	{
		close ( server );
		plog(4, "server connect err for CODER(%u.%u.%u.%u):%s\r\n", cp->ip_addr%256,(cp->ip_addr>>8)%256, (cp->ip_addr>>16)%256, cp->ip_addr>>24, strerror(errno));
		return -1;
	}
	return server;
}

int start_socket(cmd_pakg *cp)
{
	struct sockaddr_un server_addr={0};
    int socket_fd;
	char name[255];

	sprintf(name, "./tmp_socket_%d.%d.%d.%d", cp->ip_addr%256,(cp->ip_addr>>8)%256, (cp->ip_addr>>16)%256, cp->ip_addr>>24);
	unlink(name);
    socket_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    server_addr.sun_family = AF_UNIX;
	snprintf(server_addr.sun_path, UNIX_PATH_MAX, "%s", name);

    if(bind(socket_fd,(struct sockaddr *) &server_addr,sizeof(server_addr)) != 0)
	{
        plog(4, "bind(%s) failed:%s\r\n", name, strerror(errno));
        return -1;
    }

    if(listen(socket_fd, 5) != 0)
    {
        plog(4, "listen(%s) failed%s\r\n", name, strerror(errno));
        return -1;
    }
	return socket_fd;
}
void* stream_test(void *argv)
{
	ip_qu* head;
	cmd_pakg cp;
	int r=0;
	int coding=0;
	unsigned char buf[BUFF_SIZE];
	struct timeval timeout;
	pthread_detach(pthread_self());
	timeout.tv_sec = 1; 
	timeout.tv_usec = 0;
	while(1)
	{
		head = coders;
		while(head!=NULL)
		{
			if(monitor[head->chan]!=255)
			{
				cp.ip_addr=head->ip_addr;
				cp.port=head->port;
				cp.chan=head->chan;
				coding=StartCoding(&cp);
				setsockopt(coding, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(struct timeval));
				if(coding == -1)
				{
					monitor[cp.chan] = CODER_ERROE;
					sleep(10);
					head = head->next;
					continue;
				}
				r=recv(coding,buf,sizeof(buf),0);
				if(r<1) {monitor[head->chan]=CODER_ERROE; plog(4, "stream test for Class %d err! %s\r\n", head->chan, strerror(errno));}
				else {
					if( monitor[head->chan]>=CODER_ERROE && monitor[head->chan]<=250 ) 
					{
						plog(0, "stream test for Class %d successfully, erase error code %d\r\n", head->chan, monitor[head->chan]);
						monitor[head->chan] = 0;
					}
					else plog(0, "stream test for Class %d successfully\r\n", head->chan);
				}
				close(coding);
			}
			head = head->next;
		}
		sleep(3600);
	}
}
void stream(cmd_pakg *argv)
{
	int coding=-1;
	int maxfd;
	fd_set fds;
	int counts=0;
	int restart=0;
	int r=0, res=0;
	con_qu *head=NULL;
	struct timeval timeout;
	cmd_pakg *cp = argv;
	pthread_detach(pthread_self());
	int skt_ser = start_socket(cp);
	if(skt_ser==-1)
	{
		free(cp);
		return ;
	}
	while(1)
	{
		FD_ZERO(&fds);
		timeout.tv_sec = 0; 
		timeout.tv_usec = 1500000;
		FD_SET(skt_ser, &fds);
		maxfd = skt_ser;
		if( coding!=-1 )
		{
			FD_SET(coding, &fds);
			maxfd = maxfd>coding?maxfd:coding;
		}
		r = select(maxfd+1, &fds, 0, 0, &timeout);
		switch( r )
		{
			case -1:
					{
						plog(4, "client:服务器负载过大 Class %d!!!\r\n", cp->chan);
						usleep(1000000);
						continue;
					}
			case 0:
					{
						if(coding!=-1)
						{
							restart++;
							if( restart>3 )
							{
								restart = 0;
								plog(5, "recv CODER's TCP package time out for Class %d!! fd(%d)\r\n", cp->chan, coding);
								close(coding);
								coding = -1;
								monitor[cp->chan] = CODER_ERROE;
								if( counts!=0 )
								{
									while(head!=NULL)
									{
										head = Close(head, head);
									}
									counts=0;
								}
							}
							continue;
						}
						else sleep(1);
						continue;
					}
			default: break;
		}
		
		if(FD_ISSET(skt_ser, &fds))
		{
			int t=accept(skt_ser, 0, 0);
			head=add(head, t);
			plog(0, "Class %d. Client(fd:%d) connected in, Total:%d!\r\n", cp->chan, t, counts+1);
			if(coding == -1)
			{
				coding = StartCoding(cp);
				if(coding == -1)
				{
					monitor[cp->chan] = CODER_ERROE;
					while(head!=NULL)
					{
						head = Close(head, head);
					}
					counts=0;
				}
				else counts++;				
			}
			else counts++;
		}
		
		if(coding!=-1 && FD_ISSET(coding,&fds))
		{
			res=recv(coding,recv_buf,sizeof(recv_buf),0);
			if(res<1)
			{
LOOP:			if( restart++>4 )
				{
					restart = 0;
		plog(4, "Class %d. The connect break from CODER automatically!!! CODER fd(%d)\r\n", cp->chan, coding);
					if( counts!=0 )
					{
						while(head!=NULL)
						{
							head = Close(head, head);
						}
						counts=0;
					}
					close(coding);
					coding = -1;
				}
				else
				{
					plog(4, "Class %d. Socket break form CODER! MSG:%s. AUTO Repaired.(CLOSE:%d)\r\n", cp->chan, strerror(errno), 5-restart);
					if(coding!=-1)close(coding);
					coding = StartCoding(cp);
					if(coding==-1)goto LOOP;
				}
				continue;
			}
			restart = 0;
			con_qu *qu = head;
			while(qu!=NULL)
			{
				r = send(qu->fd, recv_buf, res, 0);//MSG_DONTWAIT
				if( r!=-1 )
				{
					qu = qu->next;
				}
				else
				{
					r=0;
					plog(0, "Clinet breaked(fd:%d). STREAM send err r=%d(%s). Total:%d.\r\n", qu->fd, r, strerror(errno), counts-1);
					if(qu==head){head=Close(head, qu);qu=head;}
					else qu=Close(head, qu);
					counts--;
					if(counts<1)
					{
						plog(0, "STREAM counts=%d<1, close coding.\r\n", counts);
						close(coding);
						coding = -1;
					}
				}
			}
		}
		
	}
	free(cp);
}

void main(int argc, char** argv)
{
	char ads[50];
	int msgid=atoi(argv[1]);
	int id=3;
	printf("STREAM:\targc=%d, argv[1]=%d\r\n", argc, msgid);
	get_path("[STREAM-LOG]", "/var/log/drs8/STREAM", ads, &id);
	init_LOG(msgid, id, ads, "[STREAM]");
	int pipe=pipe_init();
	state_init();
	int r=0;
	pthread_t ts;
	cmd_pakg *cp = NULL;
	r = pthread_create(&ts, NULL, &stream_test, NULL);
	if (r != 0)
	{
		plog(4, "test pthread_child error:%s\r\n", strerror(errno));
		r=0;
//		return;
	}
	while(1)
	{
		cp = (cmd_pakg *)malloc( sizeof(cmd_pakg) );
		if( cp==NULL )
		{
			plog(1, "malloc failed!\r\n");
			sleep(2);
			continue;
		}
		r= read(pipe,cp,sizeof(cmd_pakg));
		plog(0, "STREAM recv %d length cmds\r\n", r);
		plog(0, "cp->chan:%d;cp->cmd:%d;cp->ip_addr:%u.%u.%u.%u;cp->port:%d\r\n", cp->chan, cp->cmd, cp->ip_addr%256,(cp->ip_addr>>8)%256, (cp->ip_addr>>16)%256, cp->ip_addr>>24, cp->port);
		if( cp->chan==0 )
		{
			plog(4, "There is no channel ZERO!\r\n");
			free(cp);
			continue;
		}
		if(cp->ip_addr==0 || cp->ip_addr==-1)
		{
			plog(0, "process ip conitnued\r\n");
			free(cp);
			continue;
		}
		if( cmd_parse(cp) )
		{
			plog(0, "Execute the command...\r\n");
			if( fork()==0 )
			{
				signal(SIGPIPE, sig_handler);
				stream(cp);
				exit(0);
			}
		}
		else
		{
			plog(0, "Pthread existed! Ignore the command.\r\n");
		}
	}
}
